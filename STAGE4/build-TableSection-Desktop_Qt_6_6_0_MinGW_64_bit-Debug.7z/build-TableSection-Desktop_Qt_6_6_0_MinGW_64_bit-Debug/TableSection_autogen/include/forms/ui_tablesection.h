/********************************************************************************
** Form generated from reading UI file 'tablesection.ui'
**
** Created by: Qt User Interface Compiler version 6.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TABLESECTION_H
#define UI_TABLESECTION_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_TableSection
{
public:
    QGridLayout *gridLayout_2;
    QFrame *Legend;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer_3;
    QWidget *widget;
    QGridLayout *gridLayout_3;
    QLabel *lblColor12;
    QLabel *lbl2;
    QLabel *lblColor6;
    QLabel *lbl10;
    QLabel *lbl6;
    QLabel *lbl8;
    QLabel *lblColor7;
    QLabel *lblColor11;
    QLabel *lbl11;
    QLabel *lblColor5;
    QLabel *lblColor10;
    QLabel *lblColor4;
    QLabel *lblColor3;
    QLabel *lbl9;
    QLabel *lbl7;
    QLabel *lbl12;
    QLabel *lbl5;
    QLabel *lbl4;
    QLabel *lblColor8;
    QLabel *lbl3;
    QLabel *lblColor2;
    QLabel *lblColor9;
    QLabel *lbl;
    QLabel *lblColor;
    QSpacerItem *horizontalSpacer_4;
    QComboBox *comboBoxElementProperty;
    QSpacerItem *horizontalSpacer_5;
    QWidget *Periodic_property;
    QVBoxLayout *verticalLayout;
    QSpacerItem *verticalSpacer;
    QLabel *Title;
    QSpacerItem *verticalSpacer_3;
    QRadioButton *rbtnCategories;
    QRadioButton *rbtnMetallic_Properties;
    QRadioButton *rbtnBlocks;
    QRadioButton *rbtnPhases;
    QSpacerItem *verticalSpacer_2;
    QWidget *PeriodicTable;
    QGridLayout *gridLayout;
    QPushButton *btnHydrogen;
    QPushButton *btnHelium;
    QPushButton *btnLithium;
    QPushButton *btnBeryllium;
    QPushButton *btnBoron;
    QPushButton *btnCarbon;
    QPushButton *btnNitrogen;
    QPushButton *btnOxygen;
    QPushButton *btnFluorine;
    QPushButton *btnNeon;
    QPushButton *btnSodium;
    QPushButton *btnMagnesium;
    QPushButton *btnAluminum;
    QPushButton *btnSilicon;
    QPushButton *btnPhosphorus;
    QPushButton *btnSulfur;
    QPushButton *btnChlorine;
    QPushButton *btnArgon;
    QPushButton *btnPotassium;
    QPushButton *btnCalcium;
    QPushButton *btnScandium;
    QPushButton *btnTitanium;
    QPushButton *btnVanadium;
    QPushButton *btnChromium;
    QPushButton *btnManganese;
    QPushButton *btnIron;
    QPushButton *btnCobalt;
    QPushButton *btnNickel;
    QPushButton *btnCopper;
    QPushButton *btnZinc;
    QPushButton *btnGallium;
    QPushButton *btnGermanium;
    QPushButton *btnArsenic;
    QPushButton *btnSelenium;
    QPushButton *btnBromine;
    QPushButton *btnKrypton;
    QPushButton *btnRubidium;
    QPushButton *btnStrontium;
    QPushButton *btnYttrium;
    QPushButton *btnZirconium;
    QPushButton *btnNiobium;
    QPushButton *btnMolybdenum;
    QPushButton *btnTechnetium;
    QPushButton *btnRuthenium;
    QPushButton *btnRhodium;
    QPushButton *btnPalladium;
    QPushButton *btnSilver;
    QPushButton *btnCadmium;
    QPushButton *btnIndium;
    QPushButton *btnTin;
    QPushButton *btnAntimony;
    QPushButton *btnTellurium;
    QPushButton *btnIodine;
    QPushButton *btnXenon;
    QPushButton *btnCesium;
    QPushButton *btnBarium;
    QPushButton *ctnLANTHANIDES;
    QPushButton *btnHafnium;
    QPushButton *btnTantalum;
    QPushButton *btnTungsten;
    QPushButton *btnRhenium;
    QPushButton *btnOsmium;
    QPushButton *btnIridium;
    QPushButton *btnPlatinum;
    QPushButton *btnGold;
    QPushButton *btnMercury;
    QPushButton *btnThallium;
    QPushButton *btnLead;
    QPushButton *btnBismuth;
    QPushButton *btnPolonium;
    QPushButton *btnAstatine;
    QPushButton *btnRadon;
    QPushButton *btnFrancium;
    QPushButton *btnRadium;
    QPushButton *ctnACTINIDES;
    QPushButton *btnRutherfordium;
    QPushButton *btnDubnium;
    QPushButton *btnSeaborgium;
    QPushButton *btnBohrium;
    QPushButton *btnHassium;
    QPushButton *btnMeitnerium;
    QPushButton *btnDarmstadtium;
    QPushButton *btnRoentgenium;
    QPushButton *btnCopernicium;
    QPushButton *btnNihonium;
    QPushButton *btnFlerovium;
    QPushButton *btnMoscovium;
    QPushButton *btnLivermorium;
    QPushButton *btnTennessine;
    QPushButton *btnOganesson;
    QPushButton *btnLanthanum;
    QPushButton *btnCerium;
    QPushButton *btnPraseodymium;
    QPushButton *btnNeodymium;
    QPushButton *btnPromethium;
    QPushButton *btnSamarium;
    QPushButton *btnEuropium;
    QPushButton *btnGadolinium;
    QPushButton *btnTerbium;
    QPushButton *btnDysprosium;
    QPushButton *btnHolmium;
    QPushButton *btnErbium;
    QPushButton *btnThulium;
    QPushButton *btnYtterbium;
    QPushButton *btnLutetium;
    QPushButton *btnActinium;
    QPushButton *btnThorium;
    QPushButton *btnProtactinium;
    QPushButton *btnUranium;
    QPushButton *btnNeptunium;
    QPushButton *btnPlutonium;
    QPushButton *btnAmericium;
    QPushButton *btnCurium;
    QPushButton *btnBerkelium;
    QPushButton *btnCalifornium;
    QPushButton *btnEinsteinium;
    QPushButton *btnFermium;
    QPushButton *btnMendelevium;
    QPushButton *btnNobelium;
    QPushButton *btnLawrencium;
    QSpacerItem *horizontalSpacer;

    void setupUi(QWidget *TableSection)
    {
        if (TableSection->objectName().isEmpty())
            TableSection->setObjectName("TableSection");
        TableSection->resize(775, 450);
        gridLayout_2 = new QGridLayout(TableSection);
        gridLayout_2->setSpacing(0);
        gridLayout_2->setObjectName("gridLayout_2");
        gridLayout_2->setContentsMargins(0, 0, 0, 0);
        Legend = new QFrame(TableSection);
        Legend->setObjectName("Legend");
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(2);
        sizePolicy.setHeightForWidth(Legend->sizePolicy().hasHeightForWidth());
        Legend->setSizePolicy(sizePolicy);
        Legend->setMinimumSize(QSize(150, 150));
        horizontalLayout = new QHBoxLayout(Legend);
        horizontalLayout->setObjectName("horizontalLayout");
        horizontalLayout->setSizeConstraint(QLayout::SetDefaultConstraint);
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_3);

        widget = new QWidget(Legend);
        widget->setObjectName("widget");
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(widget->sizePolicy().hasHeightForWidth());
        widget->setSizePolicy(sizePolicy1);
        widget->setMinimumSize(QSize(0, 0));
        widget->setStyleSheet(QString::fromUtf8(""));
        gridLayout_3 = new QGridLayout(widget);
        gridLayout_3->setObjectName("gridLayout_3");
        gridLayout_3->setHorizontalSpacing(6);
        gridLayout_3->setVerticalSpacing(4);
        gridLayout_3->setContentsMargins(0, 20, 0, 0);
        lblColor12 = new QLabel(widget);
        lblColor12->setObjectName("lblColor12");
        QSizePolicy sizePolicy2(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(lblColor12->sizePolicy().hasHeightForWidth());
        lblColor12->setSizePolicy(sizePolicy2);
        lblColor12->setMinimumSize(QSize(16, 8));
        lblColor12->setStyleSheet(QString::fromUtf8("background-color: rgb(67, 68, 77);"));
        lblColor12->setFrameShape(QFrame::Box);
        lblColor12->setFrameShadow(QFrame::Plain);
        lblColor12->setLineWidth(1);

        gridLayout_3->addWidget(lblColor12, 5, 2, 1, 1);

        lbl2 = new QLabel(widget);
        lbl2->setObjectName("lbl2");
        sizePolicy1.setHeightForWidth(lbl2->sizePolicy().hasHeightForWidth());
        lbl2->setSizePolicy(sizePolicy1);
        lbl2->setMinimumSize(QSize(80, 10));
        QFont font;
        font.setFamilies({QString::fromUtf8("Fira Sans")});
        lbl2->setFont(font);

        gridLayout_3->addWidget(lbl2, 1, 1, 1, 1);

        lblColor6 = new QLabel(widget);
        lblColor6->setObjectName("lblColor6");
        sizePolicy2.setHeightForWidth(lblColor6->sizePolicy().hasHeightForWidth());
        lblColor6->setSizePolicy(sizePolicy2);
        lblColor6->setMinimumSize(QSize(16, 8));
        lblColor6->setStyleSheet(QString::fromUtf8("background-color: rgb(67, 68, 77);"));
        lblColor6->setFrameShape(QFrame::Box);
        lblColor6->setFrameShadow(QFrame::Plain);
        lblColor6->setLineWidth(1);

        gridLayout_3->addWidget(lblColor6, 5, 0, 1, 1);

        lbl10 = new QLabel(widget);
        lbl10->setObjectName("lbl10");
        sizePolicy1.setHeightForWidth(lbl10->sizePolicy().hasHeightForWidth());
        lbl10->setSizePolicy(sizePolicy1);
        lbl10->setMinimumSize(QSize(80, 10));
        lbl10->setFont(font);

        gridLayout_3->addWidget(lbl10, 3, 3, 1, 1);

        lbl6 = new QLabel(widget);
        lbl6->setObjectName("lbl6");
        sizePolicy1.setHeightForWidth(lbl6->sizePolicy().hasHeightForWidth());
        lbl6->setSizePolicy(sizePolicy1);
        lbl6->setMinimumSize(QSize(80, 10));
        lbl6->setFont(font);

        gridLayout_3->addWidget(lbl6, 5, 1, 1, 1);

        lbl8 = new QLabel(widget);
        lbl8->setObjectName("lbl8");
        sizePolicy1.setHeightForWidth(lbl8->sizePolicy().hasHeightForWidth());
        lbl8->setSizePolicy(sizePolicy1);
        lbl8->setMinimumSize(QSize(80, 10));
        lbl8->setFont(font);

        gridLayout_3->addWidget(lbl8, 1, 3, 1, 1);

        lblColor7 = new QLabel(widget);
        lblColor7->setObjectName("lblColor7");
        sizePolicy2.setHeightForWidth(lblColor7->sizePolicy().hasHeightForWidth());
        lblColor7->setSizePolicy(sizePolicy2);
        lblColor7->setMinimumSize(QSize(16, 8));
        lblColor7->setStyleSheet(QString::fromUtf8("background-color: rgb(67, 68, 77);"));
        lblColor7->setFrameShape(QFrame::Box);
        lblColor7->setFrameShadow(QFrame::Plain);
        lblColor7->setLineWidth(1);

        gridLayout_3->addWidget(lblColor7, 0, 2, 1, 1);

        lblColor11 = new QLabel(widget);
        lblColor11->setObjectName("lblColor11");
        sizePolicy2.setHeightForWidth(lblColor11->sizePolicy().hasHeightForWidth());
        lblColor11->setSizePolicy(sizePolicy2);
        lblColor11->setMinimumSize(QSize(16, 8));
        lblColor11->setStyleSheet(QString::fromUtf8("background-color: rgb(67, 68, 77);"));
        lblColor11->setFrameShape(QFrame::Box);
        lblColor11->setFrameShadow(QFrame::Plain);
        lblColor11->setLineWidth(1);

        gridLayout_3->addWidget(lblColor11, 4, 2, 1, 1);

        lbl11 = new QLabel(widget);
        lbl11->setObjectName("lbl11");
        sizePolicy1.setHeightForWidth(lbl11->sizePolicy().hasHeightForWidth());
        lbl11->setSizePolicy(sizePolicy1);
        lbl11->setMinimumSize(QSize(80, 10));
        lbl11->setFont(font);

        gridLayout_3->addWidget(lbl11, 4, 3, 1, 1);

        lblColor5 = new QLabel(widget);
        lblColor5->setObjectName("lblColor5");
        sizePolicy2.setHeightForWidth(lblColor5->sizePolicy().hasHeightForWidth());
        lblColor5->setSizePolicy(sizePolicy2);
        lblColor5->setMinimumSize(QSize(16, 8));
        lblColor5->setStyleSheet(QString::fromUtf8("background-color: rgb(67, 68, 77);"));
        lblColor5->setFrameShape(QFrame::Box);
        lblColor5->setFrameShadow(QFrame::Plain);
        lblColor5->setLineWidth(1);

        gridLayout_3->addWidget(lblColor5, 4, 0, 1, 1);

        lblColor10 = new QLabel(widget);
        lblColor10->setObjectName("lblColor10");
        sizePolicy2.setHeightForWidth(lblColor10->sizePolicy().hasHeightForWidth());
        lblColor10->setSizePolicy(sizePolicy2);
        lblColor10->setMinimumSize(QSize(16, 8));
        lblColor10->setStyleSheet(QString::fromUtf8("background-color: rgb(67, 68, 77);"));
        lblColor10->setFrameShape(QFrame::Box);
        lblColor10->setFrameShadow(QFrame::Plain);
        lblColor10->setLineWidth(1);

        gridLayout_3->addWidget(lblColor10, 3, 2, 1, 1);

        lblColor4 = new QLabel(widget);
        lblColor4->setObjectName("lblColor4");
        sizePolicy2.setHeightForWidth(lblColor4->sizePolicy().hasHeightForWidth());
        lblColor4->setSizePolicy(sizePolicy2);
        lblColor4->setMinimumSize(QSize(16, 8));
        lblColor4->setStyleSheet(QString::fromUtf8("background-color: rgb(67, 68, 77);"));
        lblColor4->setFrameShape(QFrame::Box);
        lblColor4->setFrameShadow(QFrame::Plain);
        lblColor4->setLineWidth(1);

        gridLayout_3->addWidget(lblColor4, 3, 0, 1, 1);

        lblColor3 = new QLabel(widget);
        lblColor3->setObjectName("lblColor3");
        sizePolicy2.setHeightForWidth(lblColor3->sizePolicy().hasHeightForWidth());
        lblColor3->setSizePolicy(sizePolicy2);
        lblColor3->setMinimumSize(QSize(16, 8));
        lblColor3->setStyleSheet(QString::fromUtf8("background-color: rgb(67, 68, 77);"));
        lblColor3->setFrameShape(QFrame::Box);
        lblColor3->setFrameShadow(QFrame::Plain);
        lblColor3->setLineWidth(1);

        gridLayout_3->addWidget(lblColor3, 2, 0, 1, 1);

        lbl9 = new QLabel(widget);
        lbl9->setObjectName("lbl9");
        sizePolicy1.setHeightForWidth(lbl9->sizePolicy().hasHeightForWidth());
        lbl9->setSizePolicy(sizePolicy1);
        lbl9->setMinimumSize(QSize(80, 10));
        lbl9->setFont(font);

        gridLayout_3->addWidget(lbl9, 2, 3, 1, 1);

        lbl7 = new QLabel(widget);
        lbl7->setObjectName("lbl7");
        sizePolicy1.setHeightForWidth(lbl7->sizePolicy().hasHeightForWidth());
        lbl7->setSizePolicy(sizePolicy1);
        lbl7->setMinimumSize(QSize(80, 10));
        lbl7->setFont(font);

        gridLayout_3->addWidget(lbl7, 0, 3, 1, 1);

        lbl12 = new QLabel(widget);
        lbl12->setObjectName("lbl12");
        sizePolicy1.setHeightForWidth(lbl12->sizePolicy().hasHeightForWidth());
        lbl12->setSizePolicy(sizePolicy1);
        lbl12->setMinimumSize(QSize(80, 10));
        lbl12->setFont(font);

        gridLayout_3->addWidget(lbl12, 5, 3, 1, 1);

        lbl5 = new QLabel(widget);
        lbl5->setObjectName("lbl5");
        sizePolicy1.setHeightForWidth(lbl5->sizePolicy().hasHeightForWidth());
        lbl5->setSizePolicy(sizePolicy1);
        lbl5->setMinimumSize(QSize(80, 10));
        lbl5->setFont(font);

        gridLayout_3->addWidget(lbl5, 4, 1, 1, 1);

        lbl4 = new QLabel(widget);
        lbl4->setObjectName("lbl4");
        sizePolicy1.setHeightForWidth(lbl4->sizePolicy().hasHeightForWidth());
        lbl4->setSizePolicy(sizePolicy1);
        lbl4->setMinimumSize(QSize(80, 10));
        lbl4->setFont(font);

        gridLayout_3->addWidget(lbl4, 3, 1, 1, 1);

        lblColor8 = new QLabel(widget);
        lblColor8->setObjectName("lblColor8");
        sizePolicy2.setHeightForWidth(lblColor8->sizePolicy().hasHeightForWidth());
        lblColor8->setSizePolicy(sizePolicy2);
        lblColor8->setMinimumSize(QSize(16, 8));
        lblColor8->setStyleSheet(QString::fromUtf8("background-color: rgb(67, 68, 77);"));
        lblColor8->setFrameShape(QFrame::Box);
        lblColor8->setFrameShadow(QFrame::Plain);
        lblColor8->setLineWidth(1);

        gridLayout_3->addWidget(lblColor8, 1, 2, 1, 1);

        lbl3 = new QLabel(widget);
        lbl3->setObjectName("lbl3");
        sizePolicy1.setHeightForWidth(lbl3->sizePolicy().hasHeightForWidth());
        lbl3->setSizePolicy(sizePolicy1);
        lbl3->setMinimumSize(QSize(80, 10));
        lbl3->setFont(font);

        gridLayout_3->addWidget(lbl3, 2, 1, 1, 1);

        lblColor2 = new QLabel(widget);
        lblColor2->setObjectName("lblColor2");
        sizePolicy2.setHeightForWidth(lblColor2->sizePolicy().hasHeightForWidth());
        lblColor2->setSizePolicy(sizePolicy2);
        lblColor2->setMinimumSize(QSize(16, 8));
        lblColor2->setStyleSheet(QString::fromUtf8("background-color: rgb(67, 68, 77);"));
        lblColor2->setFrameShape(QFrame::Box);
        lblColor2->setFrameShadow(QFrame::Plain);
        lblColor2->setLineWidth(1);

        gridLayout_3->addWidget(lblColor2, 1, 0, 1, 1);

        lblColor9 = new QLabel(widget);
        lblColor9->setObjectName("lblColor9");
        sizePolicy2.setHeightForWidth(lblColor9->sizePolicy().hasHeightForWidth());
        lblColor9->setSizePolicy(sizePolicy2);
        lblColor9->setMinimumSize(QSize(16, 8));
        lblColor9->setStyleSheet(QString::fromUtf8("background-color: rgb(67, 68, 77);"));
        lblColor9->setFrameShape(QFrame::Box);
        lblColor9->setFrameShadow(QFrame::Plain);
        lblColor9->setLineWidth(1);

        gridLayout_3->addWidget(lblColor9, 2, 2, 1, 1);

        lbl = new QLabel(widget);
        lbl->setObjectName("lbl");
        sizePolicy1.setHeightForWidth(lbl->sizePolicy().hasHeightForWidth());
        lbl->setSizePolicy(sizePolicy1);
        lbl->setMinimumSize(QSize(80, 10));
        lbl->setFont(font);

        gridLayout_3->addWidget(lbl, 0, 1, 1, 1);

        lblColor = new QLabel(widget);
        lblColor->setObjectName("lblColor");
        sizePolicy2.setHeightForWidth(lblColor->sizePolicy().hasHeightForWidth());
        lblColor->setSizePolicy(sizePolicy2);
        lblColor->setMinimumSize(QSize(16, 8));
        lblColor->setStyleSheet(QString::fromUtf8("background-color: rgb(67, 68, 77);"));
        lblColor->setFrameShape(QFrame::Box);
        lblColor->setFrameShadow(QFrame::Plain);
        lblColor->setLineWidth(1);

        gridLayout_3->addWidget(lblColor, 0, 0, 1, 1);


        horizontalLayout->addWidget(widget);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_4);

        comboBoxElementProperty = new QComboBox(Legend);
        comboBoxElementProperty->addItem(QString());
        comboBoxElementProperty->addItem(QString());
        comboBoxElementProperty->addItem(QString());
        comboBoxElementProperty->addItem(QString());
        comboBoxElementProperty->addItem(QString());
        comboBoxElementProperty->addItem(QString());
        comboBoxElementProperty->addItem(QString());
        comboBoxElementProperty->addItem(QString());
        comboBoxElementProperty->addItem(QString());
        comboBoxElementProperty->addItem(QString());
        comboBoxElementProperty->addItem(QString());
        comboBoxElementProperty->addItem(QString());
        comboBoxElementProperty->addItem(QString());
        comboBoxElementProperty->addItem(QString());
        comboBoxElementProperty->setObjectName("comboBoxElementProperty");

        horizontalLayout->addWidget(comboBoxElementProperty);

        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_5);

        horizontalLayout->setStretch(0, 5);
        horizontalLayout->setStretch(2, 2);
        horizontalLayout->setStretch(3, 5);
        horizontalLayout->setStretch(4, 3);

        gridLayout_2->addWidget(Legend, 0, 1, 1, 1);

        Periodic_property = new QWidget(TableSection);
        Periodic_property->setObjectName("Periodic_property");
        QSizePolicy sizePolicy3(QSizePolicy::Fixed, QSizePolicy::Preferred);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(Periodic_property->sizePolicy().hasHeightForWidth());
        Periodic_property->setSizePolicy(sizePolicy3);
        verticalLayout = new QVBoxLayout(Periodic_property);
        verticalLayout->setObjectName("verticalLayout");
        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        Title = new QLabel(Periodic_property);
        Title->setObjectName("Title");
        QFont font1;
        font1.setFamilies({QString::fromUtf8("Roboto Slab")});
        font1.setPointSize(14);
        font1.setBold(true);
        font1.setUnderline(true);
        Title->setFont(font1);
        Title->setMidLineWidth(0);
        Title->setAlignment(Qt::AlignCenter);
        Title->setMargin(0);
        Title->setIndent(-1);

        verticalLayout->addWidget(Title);

        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_3);

        rbtnCategories = new QRadioButton(Periodic_property);
        rbtnCategories->setObjectName("rbtnCategories");
        rbtnCategories->setLayoutDirection(Qt::LeftToRight);

        verticalLayout->addWidget(rbtnCategories);

        rbtnMetallic_Properties = new QRadioButton(Periodic_property);
        rbtnMetallic_Properties->setObjectName("rbtnMetallic_Properties");
        rbtnMetallic_Properties->setLayoutDirection(Qt::LeftToRight);

        verticalLayout->addWidget(rbtnMetallic_Properties);

        rbtnBlocks = new QRadioButton(Periodic_property);
        rbtnBlocks->setObjectName("rbtnBlocks");
        rbtnBlocks->setLayoutDirection(Qt::LeftToRight);
        rbtnBlocks->setIconSize(QSize(18, 18));

        verticalLayout->addWidget(rbtnBlocks);

        rbtnPhases = new QRadioButton(Periodic_property);
        rbtnPhases->setObjectName("rbtnPhases");
        rbtnPhases->setLayoutDirection(Qt::LeftToRight);

        verticalLayout->addWidget(rbtnPhases);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_2);

        verticalLayout->setStretch(0, 10);
        verticalLayout->setStretch(1, 2);
        verticalLayout->setStretch(2, 1);
        verticalLayout->setStretch(3, 2);
        verticalLayout->setStretch(4, 2);
        verticalLayout->setStretch(5, 2);
        verticalLayout->setStretch(6, 2);
        verticalLayout->setStretch(7, 8);

        gridLayout_2->addWidget(Periodic_property, 0, 0, 2, 1);

        PeriodicTable = new QWidget(TableSection);
        PeriodicTable->setObjectName("PeriodicTable");
        PeriodicTable->setMinimumSize(QSize(600, 300));
        gridLayout = new QGridLayout(PeriodicTable);
        gridLayout->setSpacing(2);
        gridLayout->setObjectName("gridLayout");
        gridLayout->setContentsMargins(-1, -1, 60, 40);
        btnHydrogen = new QPushButton(PeriodicTable);
        btnHydrogen->setObjectName("btnHydrogen");
        btnHydrogen->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnHydrogen->sizePolicy().hasHeightForWidth());
        btnHydrogen->setSizePolicy(sizePolicy1);
        btnHydrogen->setStyleSheet(QString::fromUtf8(""));

        gridLayout->addWidget(btnHydrogen, 0, 0, 1, 1);

        btnHelium = new QPushButton(PeriodicTable);
        btnHelium->setObjectName("btnHelium");
        btnHelium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnHelium->sizePolicy().hasHeightForWidth());
        btnHelium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnHelium, 0, 17, 1, 1);

        btnLithium = new QPushButton(PeriodicTable);
        btnLithium->setObjectName("btnLithium");
        btnLithium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnLithium->sizePolicy().hasHeightForWidth());
        btnLithium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnLithium, 1, 0, 1, 1);

        btnBeryllium = new QPushButton(PeriodicTable);
        btnBeryllium->setObjectName("btnBeryllium");
        btnBeryllium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnBeryllium->sizePolicy().hasHeightForWidth());
        btnBeryllium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnBeryllium, 1, 1, 1, 1);

        btnBoron = new QPushButton(PeriodicTable);
        btnBoron->setObjectName("btnBoron");
        btnBoron->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnBoron->sizePolicy().hasHeightForWidth());
        btnBoron->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnBoron, 1, 12, 1, 1);

        btnCarbon = new QPushButton(PeriodicTable);
        btnCarbon->setObjectName("btnCarbon");
        btnCarbon->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnCarbon->sizePolicy().hasHeightForWidth());
        btnCarbon->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnCarbon, 1, 13, 1, 1);

        btnNitrogen = new QPushButton(PeriodicTable);
        btnNitrogen->setObjectName("btnNitrogen");
        btnNitrogen->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnNitrogen->sizePolicy().hasHeightForWidth());
        btnNitrogen->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnNitrogen, 1, 14, 1, 1);

        btnOxygen = new QPushButton(PeriodicTable);
        btnOxygen->setObjectName("btnOxygen");
        btnOxygen->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnOxygen->sizePolicy().hasHeightForWidth());
        btnOxygen->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnOxygen, 1, 15, 1, 1);

        btnFluorine = new QPushButton(PeriodicTable);
        btnFluorine->setObjectName("btnFluorine");
        btnFluorine->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnFluorine->sizePolicy().hasHeightForWidth());
        btnFluorine->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnFluorine, 1, 16, 1, 1);

        btnNeon = new QPushButton(PeriodicTable);
        btnNeon->setObjectName("btnNeon");
        btnNeon->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnNeon->sizePolicy().hasHeightForWidth());
        btnNeon->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnNeon, 1, 17, 1, 1);

        btnSodium = new QPushButton(PeriodicTable);
        btnSodium->setObjectName("btnSodium");
        btnSodium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnSodium->sizePolicy().hasHeightForWidth());
        btnSodium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnSodium, 2, 0, 1, 1);

        btnMagnesium = new QPushButton(PeriodicTable);
        btnMagnesium->setObjectName("btnMagnesium");
        btnMagnesium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnMagnesium->sizePolicy().hasHeightForWidth());
        btnMagnesium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnMagnesium, 2, 1, 1, 1);

        btnAluminum = new QPushButton(PeriodicTable);
        btnAluminum->setObjectName("btnAluminum");
        btnAluminum->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnAluminum->sizePolicy().hasHeightForWidth());
        btnAluminum->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnAluminum, 2, 12, 1, 1);

        btnSilicon = new QPushButton(PeriodicTable);
        btnSilicon->setObjectName("btnSilicon");
        btnSilicon->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnSilicon->sizePolicy().hasHeightForWidth());
        btnSilicon->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnSilicon, 2, 13, 1, 1);

        btnPhosphorus = new QPushButton(PeriodicTable);
        btnPhosphorus->setObjectName("btnPhosphorus");
        btnPhosphorus->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnPhosphorus->sizePolicy().hasHeightForWidth());
        btnPhosphorus->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnPhosphorus, 2, 14, 1, 1);

        btnSulfur = new QPushButton(PeriodicTable);
        btnSulfur->setObjectName("btnSulfur");
        btnSulfur->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnSulfur->sizePolicy().hasHeightForWidth());
        btnSulfur->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnSulfur, 2, 15, 1, 1);

        btnChlorine = new QPushButton(PeriodicTable);
        btnChlorine->setObjectName("btnChlorine");
        btnChlorine->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnChlorine->sizePolicy().hasHeightForWidth());
        btnChlorine->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnChlorine, 2, 16, 1, 1);

        btnArgon = new QPushButton(PeriodicTable);
        btnArgon->setObjectName("btnArgon");
        btnArgon->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnArgon->sizePolicy().hasHeightForWidth());
        btnArgon->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnArgon, 2, 17, 1, 1);

        btnPotassium = new QPushButton(PeriodicTable);
        btnPotassium->setObjectName("btnPotassium");
        btnPotassium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnPotassium->sizePolicy().hasHeightForWidth());
        btnPotassium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnPotassium, 3, 0, 1, 1);

        btnCalcium = new QPushButton(PeriodicTable);
        btnCalcium->setObjectName("btnCalcium");
        btnCalcium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnCalcium->sizePolicy().hasHeightForWidth());
        btnCalcium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnCalcium, 3, 1, 1, 1);

        btnScandium = new QPushButton(PeriodicTable);
        btnScandium->setObjectName("btnScandium");
        btnScandium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnScandium->sizePolicy().hasHeightForWidth());
        btnScandium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnScandium, 3, 2, 1, 1);

        btnTitanium = new QPushButton(PeriodicTable);
        btnTitanium->setObjectName("btnTitanium");
        btnTitanium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnTitanium->sizePolicy().hasHeightForWidth());
        btnTitanium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnTitanium, 3, 3, 1, 1);

        btnVanadium = new QPushButton(PeriodicTable);
        btnVanadium->setObjectName("btnVanadium");
        btnVanadium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnVanadium->sizePolicy().hasHeightForWidth());
        btnVanadium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnVanadium, 3, 4, 1, 1);

        btnChromium = new QPushButton(PeriodicTable);
        btnChromium->setObjectName("btnChromium");
        btnChromium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnChromium->sizePolicy().hasHeightForWidth());
        btnChromium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnChromium, 3, 5, 1, 1);

        btnManganese = new QPushButton(PeriodicTable);
        btnManganese->setObjectName("btnManganese");
        btnManganese->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnManganese->sizePolicy().hasHeightForWidth());
        btnManganese->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnManganese, 3, 6, 1, 1);

        btnIron = new QPushButton(PeriodicTable);
        btnIron->setObjectName("btnIron");
        btnIron->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnIron->sizePolicy().hasHeightForWidth());
        btnIron->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnIron, 3, 7, 1, 1);

        btnCobalt = new QPushButton(PeriodicTable);
        btnCobalt->setObjectName("btnCobalt");
        btnCobalt->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnCobalt->sizePolicy().hasHeightForWidth());
        btnCobalt->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnCobalt, 3, 8, 1, 1);

        btnNickel = new QPushButton(PeriodicTable);
        btnNickel->setObjectName("btnNickel");
        btnNickel->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnNickel->sizePolicy().hasHeightForWidth());
        btnNickel->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnNickel, 3, 9, 1, 1);

        btnCopper = new QPushButton(PeriodicTable);
        btnCopper->setObjectName("btnCopper");
        btnCopper->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnCopper->sizePolicy().hasHeightForWidth());
        btnCopper->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnCopper, 3, 10, 1, 1);

        btnZinc = new QPushButton(PeriodicTable);
        btnZinc->setObjectName("btnZinc");
        btnZinc->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnZinc->sizePolicy().hasHeightForWidth());
        btnZinc->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnZinc, 3, 11, 1, 1);

        btnGallium = new QPushButton(PeriodicTable);
        btnGallium->setObjectName("btnGallium");
        btnGallium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnGallium->sizePolicy().hasHeightForWidth());
        btnGallium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnGallium, 3, 12, 1, 1);

        btnGermanium = new QPushButton(PeriodicTable);
        btnGermanium->setObjectName("btnGermanium");
        btnGermanium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnGermanium->sizePolicy().hasHeightForWidth());
        btnGermanium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnGermanium, 3, 13, 1, 1);

        btnArsenic = new QPushButton(PeriodicTable);
        btnArsenic->setObjectName("btnArsenic");
        btnArsenic->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnArsenic->sizePolicy().hasHeightForWidth());
        btnArsenic->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnArsenic, 3, 14, 1, 1);

        btnSelenium = new QPushButton(PeriodicTable);
        btnSelenium->setObjectName("btnSelenium");
        btnSelenium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnSelenium->sizePolicy().hasHeightForWidth());
        btnSelenium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnSelenium, 3, 15, 1, 1);

        btnBromine = new QPushButton(PeriodicTable);
        btnBromine->setObjectName("btnBromine");
        btnBromine->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnBromine->sizePolicy().hasHeightForWidth());
        btnBromine->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnBromine, 3, 16, 1, 1);

        btnKrypton = new QPushButton(PeriodicTable);
        btnKrypton->setObjectName("btnKrypton");
        btnKrypton->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnKrypton->sizePolicy().hasHeightForWidth());
        btnKrypton->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnKrypton, 3, 17, 1, 1);

        btnRubidium = new QPushButton(PeriodicTable);
        btnRubidium->setObjectName("btnRubidium");
        btnRubidium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnRubidium->sizePolicy().hasHeightForWidth());
        btnRubidium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnRubidium, 4, 0, 1, 1);

        btnStrontium = new QPushButton(PeriodicTable);
        btnStrontium->setObjectName("btnStrontium");
        btnStrontium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnStrontium->sizePolicy().hasHeightForWidth());
        btnStrontium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnStrontium, 4, 1, 1, 1);

        btnYttrium = new QPushButton(PeriodicTable);
        btnYttrium->setObjectName("btnYttrium");
        btnYttrium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnYttrium->sizePolicy().hasHeightForWidth());
        btnYttrium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnYttrium, 4, 2, 1, 1);

        btnZirconium = new QPushButton(PeriodicTable);
        btnZirconium->setObjectName("btnZirconium");
        btnZirconium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnZirconium->sizePolicy().hasHeightForWidth());
        btnZirconium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnZirconium, 4, 3, 1, 1);

        btnNiobium = new QPushButton(PeriodicTable);
        btnNiobium->setObjectName("btnNiobium");
        btnNiobium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnNiobium->sizePolicy().hasHeightForWidth());
        btnNiobium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnNiobium, 4, 4, 1, 1);

        btnMolybdenum = new QPushButton(PeriodicTable);
        btnMolybdenum->setObjectName("btnMolybdenum");
        btnMolybdenum->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnMolybdenum->sizePolicy().hasHeightForWidth());
        btnMolybdenum->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnMolybdenum, 4, 5, 1, 1);

        btnTechnetium = new QPushButton(PeriodicTable);
        btnTechnetium->setObjectName("btnTechnetium");
        btnTechnetium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnTechnetium->sizePolicy().hasHeightForWidth());
        btnTechnetium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnTechnetium, 4, 6, 1, 1);

        btnRuthenium = new QPushButton(PeriodicTable);
        btnRuthenium->setObjectName("btnRuthenium");
        btnRuthenium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnRuthenium->sizePolicy().hasHeightForWidth());
        btnRuthenium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnRuthenium, 4, 7, 1, 1);

        btnRhodium = new QPushButton(PeriodicTable);
        btnRhodium->setObjectName("btnRhodium");
        btnRhodium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnRhodium->sizePolicy().hasHeightForWidth());
        btnRhodium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnRhodium, 4, 8, 1, 1);

        btnPalladium = new QPushButton(PeriodicTable);
        btnPalladium->setObjectName("btnPalladium");
        btnPalladium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnPalladium->sizePolicy().hasHeightForWidth());
        btnPalladium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnPalladium, 4, 9, 1, 1);

        btnSilver = new QPushButton(PeriodicTable);
        btnSilver->setObjectName("btnSilver");
        btnSilver->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnSilver->sizePolicy().hasHeightForWidth());
        btnSilver->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnSilver, 4, 10, 1, 1);

        btnCadmium = new QPushButton(PeriodicTable);
        btnCadmium->setObjectName("btnCadmium");
        btnCadmium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnCadmium->sizePolicy().hasHeightForWidth());
        btnCadmium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnCadmium, 4, 11, 1, 1);

        btnIndium = new QPushButton(PeriodicTable);
        btnIndium->setObjectName("btnIndium");
        btnIndium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnIndium->sizePolicy().hasHeightForWidth());
        btnIndium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnIndium, 4, 12, 1, 1);

        btnTin = new QPushButton(PeriodicTable);
        btnTin->setObjectName("btnTin");
        btnTin->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnTin->sizePolicy().hasHeightForWidth());
        btnTin->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnTin, 4, 13, 1, 1);

        btnAntimony = new QPushButton(PeriodicTable);
        btnAntimony->setObjectName("btnAntimony");
        btnAntimony->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnAntimony->sizePolicy().hasHeightForWidth());
        btnAntimony->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnAntimony, 4, 14, 1, 1);

        btnTellurium = new QPushButton(PeriodicTable);
        btnTellurium->setObjectName("btnTellurium");
        btnTellurium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnTellurium->sizePolicy().hasHeightForWidth());
        btnTellurium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnTellurium, 4, 15, 1, 1);

        btnIodine = new QPushButton(PeriodicTable);
        btnIodine->setObjectName("btnIodine");
        btnIodine->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnIodine->sizePolicy().hasHeightForWidth());
        btnIodine->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnIodine, 4, 16, 1, 1);

        btnXenon = new QPushButton(PeriodicTable);
        btnXenon->setObjectName("btnXenon");
        btnXenon->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnXenon->sizePolicy().hasHeightForWidth());
        btnXenon->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnXenon, 4, 17, 1, 1);

        btnCesium = new QPushButton(PeriodicTable);
        btnCesium->setObjectName("btnCesium");
        btnCesium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnCesium->sizePolicy().hasHeightForWidth());
        btnCesium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnCesium, 5, 0, 1, 1);

        btnBarium = new QPushButton(PeriodicTable);
        btnBarium->setObjectName("btnBarium");
        btnBarium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnBarium->sizePolicy().hasHeightForWidth());
        btnBarium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnBarium, 5, 1, 1, 1);

        ctnLANTHANIDES = new QPushButton(PeriodicTable);
        ctnLANTHANIDES->setObjectName("ctnLANTHANIDES");
        ctnLANTHANIDES->setEnabled(true);
        sizePolicy1.setHeightForWidth(ctnLANTHANIDES->sizePolicy().hasHeightForWidth());
        ctnLANTHANIDES->setSizePolicy(sizePolicy1);
        ctnLANTHANIDES->setFlat(false);

        gridLayout->addWidget(ctnLANTHANIDES, 5, 2, 1, 1);

        btnHafnium = new QPushButton(PeriodicTable);
        btnHafnium->setObjectName("btnHafnium");
        btnHafnium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnHafnium->sizePolicy().hasHeightForWidth());
        btnHafnium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnHafnium, 5, 3, 1, 1);

        btnTantalum = new QPushButton(PeriodicTable);
        btnTantalum->setObjectName("btnTantalum");
        btnTantalum->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnTantalum->sizePolicy().hasHeightForWidth());
        btnTantalum->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnTantalum, 5, 4, 1, 1);

        btnTungsten = new QPushButton(PeriodicTable);
        btnTungsten->setObjectName("btnTungsten");
        btnTungsten->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnTungsten->sizePolicy().hasHeightForWidth());
        btnTungsten->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnTungsten, 5, 5, 1, 1);

        btnRhenium = new QPushButton(PeriodicTable);
        btnRhenium->setObjectName("btnRhenium");
        btnRhenium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnRhenium->sizePolicy().hasHeightForWidth());
        btnRhenium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnRhenium, 5, 6, 1, 1);

        btnOsmium = new QPushButton(PeriodicTable);
        btnOsmium->setObjectName("btnOsmium");
        btnOsmium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnOsmium->sizePolicy().hasHeightForWidth());
        btnOsmium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnOsmium, 5, 7, 1, 1);

        btnIridium = new QPushButton(PeriodicTable);
        btnIridium->setObjectName("btnIridium");
        btnIridium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnIridium->sizePolicy().hasHeightForWidth());
        btnIridium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnIridium, 5, 8, 1, 1);

        btnPlatinum = new QPushButton(PeriodicTable);
        btnPlatinum->setObjectName("btnPlatinum");
        btnPlatinum->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnPlatinum->sizePolicy().hasHeightForWidth());
        btnPlatinum->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnPlatinum, 5, 9, 1, 1);

        btnGold = new QPushButton(PeriodicTable);
        btnGold->setObjectName("btnGold");
        btnGold->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnGold->sizePolicy().hasHeightForWidth());
        btnGold->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnGold, 5, 10, 1, 1);

        btnMercury = new QPushButton(PeriodicTable);
        btnMercury->setObjectName("btnMercury");
        btnMercury->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnMercury->sizePolicy().hasHeightForWidth());
        btnMercury->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnMercury, 5, 11, 1, 1);

        btnThallium = new QPushButton(PeriodicTable);
        btnThallium->setObjectName("btnThallium");
        btnThallium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnThallium->sizePolicy().hasHeightForWidth());
        btnThallium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnThallium, 5, 12, 1, 1);

        btnLead = new QPushButton(PeriodicTable);
        btnLead->setObjectName("btnLead");
        btnLead->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnLead->sizePolicy().hasHeightForWidth());
        btnLead->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnLead, 5, 13, 1, 1);

        btnBismuth = new QPushButton(PeriodicTable);
        btnBismuth->setObjectName("btnBismuth");
        btnBismuth->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnBismuth->sizePolicy().hasHeightForWidth());
        btnBismuth->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnBismuth, 5, 14, 1, 1);

        btnPolonium = new QPushButton(PeriodicTable);
        btnPolonium->setObjectName("btnPolonium");
        btnPolonium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnPolonium->sizePolicy().hasHeightForWidth());
        btnPolonium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnPolonium, 5, 15, 1, 1);

        btnAstatine = new QPushButton(PeriodicTable);
        btnAstatine->setObjectName("btnAstatine");
        btnAstatine->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnAstatine->sizePolicy().hasHeightForWidth());
        btnAstatine->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnAstatine, 5, 16, 1, 1);

        btnRadon = new QPushButton(PeriodicTable);
        btnRadon->setObjectName("btnRadon");
        btnRadon->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnRadon->sizePolicy().hasHeightForWidth());
        btnRadon->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnRadon, 5, 17, 1, 1);

        btnFrancium = new QPushButton(PeriodicTable);
        btnFrancium->setObjectName("btnFrancium");
        btnFrancium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnFrancium->sizePolicy().hasHeightForWidth());
        btnFrancium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnFrancium, 6, 0, 1, 1);

        btnRadium = new QPushButton(PeriodicTable);
        btnRadium->setObjectName("btnRadium");
        btnRadium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnRadium->sizePolicy().hasHeightForWidth());
        btnRadium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnRadium, 6, 1, 1, 1);

        ctnACTINIDES = new QPushButton(PeriodicTable);
        ctnACTINIDES->setObjectName("ctnACTINIDES");
        ctnACTINIDES->setEnabled(true);
        sizePolicy1.setHeightForWidth(ctnACTINIDES->sizePolicy().hasHeightForWidth());
        ctnACTINIDES->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(ctnACTINIDES, 6, 2, 1, 1);

        btnRutherfordium = new QPushButton(PeriodicTable);
        btnRutherfordium->setObjectName("btnRutherfordium");
        btnRutherfordium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnRutherfordium->sizePolicy().hasHeightForWidth());
        btnRutherfordium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnRutherfordium, 6, 3, 1, 1);

        btnDubnium = new QPushButton(PeriodicTable);
        btnDubnium->setObjectName("btnDubnium");
        btnDubnium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnDubnium->sizePolicy().hasHeightForWidth());
        btnDubnium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnDubnium, 6, 4, 1, 1);

        btnSeaborgium = new QPushButton(PeriodicTable);
        btnSeaborgium->setObjectName("btnSeaborgium");
        btnSeaborgium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnSeaborgium->sizePolicy().hasHeightForWidth());
        btnSeaborgium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnSeaborgium, 6, 5, 1, 1);

        btnBohrium = new QPushButton(PeriodicTable);
        btnBohrium->setObjectName("btnBohrium");
        btnBohrium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnBohrium->sizePolicy().hasHeightForWidth());
        btnBohrium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnBohrium, 6, 6, 1, 1);

        btnHassium = new QPushButton(PeriodicTable);
        btnHassium->setObjectName("btnHassium");
        btnHassium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnHassium->sizePolicy().hasHeightForWidth());
        btnHassium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnHassium, 6, 7, 1, 1);

        btnMeitnerium = new QPushButton(PeriodicTable);
        btnMeitnerium->setObjectName("btnMeitnerium");
        btnMeitnerium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnMeitnerium->sizePolicy().hasHeightForWidth());
        btnMeitnerium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnMeitnerium, 6, 8, 1, 1);

        btnDarmstadtium = new QPushButton(PeriodicTable);
        btnDarmstadtium->setObjectName("btnDarmstadtium");
        btnDarmstadtium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnDarmstadtium->sizePolicy().hasHeightForWidth());
        btnDarmstadtium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnDarmstadtium, 6, 9, 1, 1);

        btnRoentgenium = new QPushButton(PeriodicTable);
        btnRoentgenium->setObjectName("btnRoentgenium");
        btnRoentgenium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnRoentgenium->sizePolicy().hasHeightForWidth());
        btnRoentgenium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnRoentgenium, 6, 10, 1, 1);

        btnCopernicium = new QPushButton(PeriodicTable);
        btnCopernicium->setObjectName("btnCopernicium");
        btnCopernicium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnCopernicium->sizePolicy().hasHeightForWidth());
        btnCopernicium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnCopernicium, 6, 11, 1, 1);

        btnNihonium = new QPushButton(PeriodicTable);
        btnNihonium->setObjectName("btnNihonium");
        btnNihonium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnNihonium->sizePolicy().hasHeightForWidth());
        btnNihonium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnNihonium, 6, 12, 1, 1);

        btnFlerovium = new QPushButton(PeriodicTable);
        btnFlerovium->setObjectName("btnFlerovium");
        btnFlerovium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnFlerovium->sizePolicy().hasHeightForWidth());
        btnFlerovium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnFlerovium, 6, 13, 1, 1);

        btnMoscovium = new QPushButton(PeriodicTable);
        btnMoscovium->setObjectName("btnMoscovium");
        btnMoscovium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnMoscovium->sizePolicy().hasHeightForWidth());
        btnMoscovium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnMoscovium, 6, 14, 1, 1);

        btnLivermorium = new QPushButton(PeriodicTable);
        btnLivermorium->setObjectName("btnLivermorium");
        btnLivermorium->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnLivermorium->sizePolicy().hasHeightForWidth());
        btnLivermorium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnLivermorium, 6, 15, 1, 1);

        btnTennessine = new QPushButton(PeriodicTable);
        btnTennessine->setObjectName("btnTennessine");
        btnTennessine->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnTennessine->sizePolicy().hasHeightForWidth());
        btnTennessine->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnTennessine, 6, 16, 1, 1);

        btnOganesson = new QPushButton(PeriodicTable);
        btnOganesson->setObjectName("btnOganesson");
        btnOganesson->setEnabled(true);
        sizePolicy1.setHeightForWidth(btnOganesson->sizePolicy().hasHeightForWidth());
        btnOganesson->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnOganesson, 6, 17, 1, 1);

        btnLanthanum = new QPushButton(PeriodicTable);
        btnLanthanum->setObjectName("btnLanthanum");
        sizePolicy1.setHeightForWidth(btnLanthanum->sizePolicy().hasHeightForWidth());
        btnLanthanum->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnLanthanum, 8, 2, 1, 1);

        btnCerium = new QPushButton(PeriodicTable);
        btnCerium->setObjectName("btnCerium");
        sizePolicy1.setHeightForWidth(btnCerium->sizePolicy().hasHeightForWidth());
        btnCerium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnCerium, 8, 3, 1, 1);

        btnPraseodymium = new QPushButton(PeriodicTable);
        btnPraseodymium->setObjectName("btnPraseodymium");
        sizePolicy1.setHeightForWidth(btnPraseodymium->sizePolicy().hasHeightForWidth());
        btnPraseodymium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnPraseodymium, 8, 4, 1, 1);

        btnNeodymium = new QPushButton(PeriodicTable);
        btnNeodymium->setObjectName("btnNeodymium");
        sizePolicy1.setHeightForWidth(btnNeodymium->sizePolicy().hasHeightForWidth());
        btnNeodymium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnNeodymium, 8, 5, 1, 1);

        btnPromethium = new QPushButton(PeriodicTable);
        btnPromethium->setObjectName("btnPromethium");
        sizePolicy1.setHeightForWidth(btnPromethium->sizePolicy().hasHeightForWidth());
        btnPromethium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnPromethium, 8, 6, 1, 1);

        btnSamarium = new QPushButton(PeriodicTable);
        btnSamarium->setObjectName("btnSamarium");
        sizePolicy1.setHeightForWidth(btnSamarium->sizePolicy().hasHeightForWidth());
        btnSamarium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnSamarium, 8, 7, 1, 1);

        btnEuropium = new QPushButton(PeriodicTable);
        btnEuropium->setObjectName("btnEuropium");
        sizePolicy1.setHeightForWidth(btnEuropium->sizePolicy().hasHeightForWidth());
        btnEuropium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnEuropium, 8, 8, 1, 1);

        btnGadolinium = new QPushButton(PeriodicTable);
        btnGadolinium->setObjectName("btnGadolinium");
        sizePolicy1.setHeightForWidth(btnGadolinium->sizePolicy().hasHeightForWidth());
        btnGadolinium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnGadolinium, 8, 9, 1, 1);

        btnTerbium = new QPushButton(PeriodicTable);
        btnTerbium->setObjectName("btnTerbium");
        sizePolicy1.setHeightForWidth(btnTerbium->sizePolicy().hasHeightForWidth());
        btnTerbium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnTerbium, 8, 10, 1, 1);

        btnDysprosium = new QPushButton(PeriodicTable);
        btnDysprosium->setObjectName("btnDysprosium");
        sizePolicy1.setHeightForWidth(btnDysprosium->sizePolicy().hasHeightForWidth());
        btnDysprosium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnDysprosium, 8, 11, 1, 1);

        btnHolmium = new QPushButton(PeriodicTable);
        btnHolmium->setObjectName("btnHolmium");
        sizePolicy1.setHeightForWidth(btnHolmium->sizePolicy().hasHeightForWidth());
        btnHolmium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnHolmium, 8, 12, 1, 1);

        btnErbium = new QPushButton(PeriodicTable);
        btnErbium->setObjectName("btnErbium");
        sizePolicy1.setHeightForWidth(btnErbium->sizePolicy().hasHeightForWidth());
        btnErbium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnErbium, 8, 13, 1, 1);

        btnThulium = new QPushButton(PeriodicTable);
        btnThulium->setObjectName("btnThulium");
        sizePolicy1.setHeightForWidth(btnThulium->sizePolicy().hasHeightForWidth());
        btnThulium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnThulium, 8, 14, 1, 1);

        btnYtterbium = new QPushButton(PeriodicTable);
        btnYtterbium->setObjectName("btnYtterbium");
        sizePolicy1.setHeightForWidth(btnYtterbium->sizePolicy().hasHeightForWidth());
        btnYtterbium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnYtterbium, 8, 15, 1, 1);

        btnLutetium = new QPushButton(PeriodicTable);
        btnLutetium->setObjectName("btnLutetium");
        sizePolicy1.setHeightForWidth(btnLutetium->sizePolicy().hasHeightForWidth());
        btnLutetium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnLutetium, 8, 16, 1, 1);

        btnActinium = new QPushButton(PeriodicTable);
        btnActinium->setObjectName("btnActinium");
        sizePolicy1.setHeightForWidth(btnActinium->sizePolicy().hasHeightForWidth());
        btnActinium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnActinium, 9, 2, 1, 1);

        btnThorium = new QPushButton(PeriodicTable);
        btnThorium->setObjectName("btnThorium");
        sizePolicy1.setHeightForWidth(btnThorium->sizePolicy().hasHeightForWidth());
        btnThorium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnThorium, 9, 3, 1, 1);

        btnProtactinium = new QPushButton(PeriodicTable);
        btnProtactinium->setObjectName("btnProtactinium");
        sizePolicy1.setHeightForWidth(btnProtactinium->sizePolicy().hasHeightForWidth());
        btnProtactinium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnProtactinium, 9, 4, 1, 1);

        btnUranium = new QPushButton(PeriodicTable);
        btnUranium->setObjectName("btnUranium");
        sizePolicy1.setHeightForWidth(btnUranium->sizePolicy().hasHeightForWidth());
        btnUranium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnUranium, 9, 5, 1, 1);

        btnNeptunium = new QPushButton(PeriodicTable);
        btnNeptunium->setObjectName("btnNeptunium");
        sizePolicy1.setHeightForWidth(btnNeptunium->sizePolicy().hasHeightForWidth());
        btnNeptunium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnNeptunium, 9, 6, 1, 1);

        btnPlutonium = new QPushButton(PeriodicTable);
        btnPlutonium->setObjectName("btnPlutonium");
        sizePolicy1.setHeightForWidth(btnPlutonium->sizePolicy().hasHeightForWidth());
        btnPlutonium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnPlutonium, 9, 7, 1, 1);

        btnAmericium = new QPushButton(PeriodicTable);
        btnAmericium->setObjectName("btnAmericium");
        sizePolicy1.setHeightForWidth(btnAmericium->sizePolicy().hasHeightForWidth());
        btnAmericium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnAmericium, 9, 8, 1, 1);

        btnCurium = new QPushButton(PeriodicTable);
        btnCurium->setObjectName("btnCurium");
        sizePolicy1.setHeightForWidth(btnCurium->sizePolicy().hasHeightForWidth());
        btnCurium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnCurium, 9, 9, 1, 1);

        btnBerkelium = new QPushButton(PeriodicTable);
        btnBerkelium->setObjectName("btnBerkelium");
        sizePolicy1.setHeightForWidth(btnBerkelium->sizePolicy().hasHeightForWidth());
        btnBerkelium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnBerkelium, 9, 10, 1, 1);

        btnCalifornium = new QPushButton(PeriodicTable);
        btnCalifornium->setObjectName("btnCalifornium");
        sizePolicy1.setHeightForWidth(btnCalifornium->sizePolicy().hasHeightForWidth());
        btnCalifornium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnCalifornium, 9, 11, 1, 1);

        btnEinsteinium = new QPushButton(PeriodicTable);
        btnEinsteinium->setObjectName("btnEinsteinium");
        sizePolicy1.setHeightForWidth(btnEinsteinium->sizePolicy().hasHeightForWidth());
        btnEinsteinium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnEinsteinium, 9, 12, 1, 1);

        btnFermium = new QPushButton(PeriodicTable);
        btnFermium->setObjectName("btnFermium");
        sizePolicy1.setHeightForWidth(btnFermium->sizePolicy().hasHeightForWidth());
        btnFermium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnFermium, 9, 13, 1, 1);

        btnMendelevium = new QPushButton(PeriodicTable);
        btnMendelevium->setObjectName("btnMendelevium");
        sizePolicy1.setHeightForWidth(btnMendelevium->sizePolicy().hasHeightForWidth());
        btnMendelevium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnMendelevium, 9, 14, 1, 1);

        btnNobelium = new QPushButton(PeriodicTable);
        btnNobelium->setObjectName("btnNobelium");
        sizePolicy1.setHeightForWidth(btnNobelium->sizePolicy().hasHeightForWidth());
        btnNobelium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnNobelium, 9, 15, 1, 1);

        btnLawrencium = new QPushButton(PeriodicTable);
        btnLawrencium->setObjectName("btnLawrencium");
        sizePolicy1.setHeightForWidth(btnLawrencium->sizePolicy().hasHeightForWidth());
        btnLawrencium->setSizePolicy(sizePolicy1);

        gridLayout->addWidget(btnLawrencium, 9, 16, 1, 1);

        horizontalSpacer = new QSpacerItem(740, 44, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer, 7, 0, 1, 18);


        gridLayout_2->addWidget(PeriodicTable, 1, 1, 1, 1);

        gridLayout_2->setRowStretch(0, 1);
        gridLayout_2->setRowStretch(1, 4);
        gridLayout_2->setColumnStretch(0, 1);
        gridLayout_2->setColumnStretch(1, 4);

        retranslateUi(TableSection);

        QMetaObject::connectSlotsByName(TableSection);
    } // setupUi

    void retranslateUi(QWidget *TableSection)
    {
        TableSection->setWindowTitle(QCoreApplication::translate("TableSection", "TableSection", nullptr));
        lblColor12->setText(QString());
        lbl2->setText(QCoreApplication::translate("TableSection", "TextLabel", nullptr));
        lblColor6->setText(QString());
        lbl10->setText(QCoreApplication::translate("TableSection", "TextLabel", nullptr));
        lbl6->setText(QCoreApplication::translate("TableSection", "TextLabel", nullptr));
        lbl8->setText(QCoreApplication::translate("TableSection", "TextLabel", nullptr));
        lblColor7->setText(QString());
        lblColor11->setText(QString());
        lbl11->setText(QCoreApplication::translate("TableSection", "TextLabel", nullptr));
        lblColor5->setText(QString());
        lblColor10->setText(QString());
        lblColor4->setText(QString());
        lblColor3->setText(QString());
        lbl9->setText(QCoreApplication::translate("TableSection", "TextLabel", nullptr));
        lbl7->setText(QCoreApplication::translate("TableSection", "TextLabel", nullptr));
        lbl12->setText(QCoreApplication::translate("TableSection", "TextLabel", nullptr));
        lbl5->setText(QCoreApplication::translate("TableSection", "TextLabel", nullptr));
        lbl4->setText(QCoreApplication::translate("TableSection", "TextLabel", nullptr));
        lblColor8->setText(QString());
        lbl3->setText(QCoreApplication::translate("TableSection", "TextLabel", nullptr));
        lblColor2->setText(QString());
        lblColor9->setText(QString());
        lbl->setText(QCoreApplication::translate("TableSection", "TextLabel", nullptr));
        lblColor->setText(QString());
        comboBoxElementProperty->setItemText(0, QCoreApplication::translate("TableSection", "Simple", nullptr));
        comboBoxElementProperty->setItemText(1, QCoreApplication::translate("TableSection", "Element Name", nullptr));
        comboBoxElementProperty->setItemText(2, QCoreApplication::translate("TableSection", "Atomic Mass", nullptr));
        comboBoxElementProperty->setItemText(3, QCoreApplication::translate("TableSection", "Atomic Radius", nullptr));
        comboBoxElementProperty->setItemText(4, QCoreApplication::translate("TableSection", "Boiling Point", nullptr));
        comboBoxElementProperty->setItemText(5, QCoreApplication::translate("TableSection", "Melting Point", nullptr));
        comboBoxElementProperty->setItemText(6, QCoreApplication::translate("TableSection", "Electron Configuration", nullptr));
        comboBoxElementProperty->setItemText(7, QCoreApplication::translate("TableSection", "Electronegativity", nullptr));
        comboBoxElementProperty->setItemText(8, QCoreApplication::translate("TableSection", "Oxidation State", nullptr));
        comboBoxElementProperty->setItemText(9, QCoreApplication::translate("TableSection", "Ionization Energy", nullptr));
        comboBoxElementProperty->setItemText(10, QCoreApplication::translate("TableSection", "Electron Affinity", nullptr));
        comboBoxElementProperty->setItemText(11, QCoreApplication::translate("TableSection", "Density", nullptr));
        comboBoxElementProperty->setItemText(12, QCoreApplication::translate("TableSection", "Discovery Year", nullptr));
        comboBoxElementProperty->setItemText(13, QCoreApplication::translate("TableSection", "Discovered By", nullptr));

        Title->setText(QCoreApplication::translate("TableSection", "COLORING", nullptr));
        rbtnCategories->setText(QCoreApplication::translate("TableSection", "Categories", nullptr));
        rbtnMetallic_Properties->setText(QCoreApplication::translate("TableSection", "Metallic Properties", nullptr));
        rbtnBlocks->setText(QCoreApplication::translate("TableSection", "Blocks", nullptr));
        rbtnPhases->setText(QCoreApplication::translate("TableSection", "Phases", nullptr));
#if QT_CONFIG(tooltip)
        btnHydrogen->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(statustip)
        btnHydrogen->setStatusTip(QString());
#endif // QT_CONFIG(statustip)
        btnHydrogen->setText(QCoreApplication::translate("TableSection", "H", nullptr));
        btnHelium->setText(QCoreApplication::translate("TableSection", "He", nullptr));
        btnLithium->setText(QCoreApplication::translate("TableSection", "Li", nullptr));
        btnBeryllium->setText(QCoreApplication::translate("TableSection", "Be", nullptr));
        btnBoron->setText(QCoreApplication::translate("TableSection", "B", nullptr));
        btnCarbon->setText(QCoreApplication::translate("TableSection", "C", nullptr));
        btnNitrogen->setText(QCoreApplication::translate("TableSection", "N", nullptr));
        btnOxygen->setText(QCoreApplication::translate("TableSection", "O", nullptr));
        btnFluorine->setText(QCoreApplication::translate("TableSection", "F", nullptr));
        btnNeon->setText(QCoreApplication::translate("TableSection", "Ne", nullptr));
        btnSodium->setText(QCoreApplication::translate("TableSection", "Na", nullptr));
        btnMagnesium->setText(QCoreApplication::translate("TableSection", "Mg", nullptr));
        btnAluminum->setText(QCoreApplication::translate("TableSection", "Al", nullptr));
        btnSilicon->setText(QCoreApplication::translate("TableSection", "Si", nullptr));
        btnPhosphorus->setText(QCoreApplication::translate("TableSection", "P", nullptr));
        btnSulfur->setText(QCoreApplication::translate("TableSection", "S", nullptr));
        btnChlorine->setText(QCoreApplication::translate("TableSection", "Cl", nullptr));
        btnArgon->setText(QCoreApplication::translate("TableSection", "Ar", nullptr));
        btnPotassium->setText(QCoreApplication::translate("TableSection", "K", nullptr));
        btnCalcium->setText(QCoreApplication::translate("TableSection", "Ca", nullptr));
        btnScandium->setText(QCoreApplication::translate("TableSection", "Sc", nullptr));
        btnTitanium->setText(QCoreApplication::translate("TableSection", "Ti", nullptr));
        btnVanadium->setText(QCoreApplication::translate("TableSection", "V", nullptr));
        btnChromium->setText(QCoreApplication::translate("TableSection", "Cr", nullptr));
        btnManganese->setText(QCoreApplication::translate("TableSection", "Mn", nullptr));
        btnIron->setText(QCoreApplication::translate("TableSection", "Fe", nullptr));
        btnCobalt->setText(QCoreApplication::translate("TableSection", "Co", nullptr));
        btnNickel->setText(QCoreApplication::translate("TableSection", "Ni", nullptr));
        btnCopper->setText(QCoreApplication::translate("TableSection", "Cu", nullptr));
        btnZinc->setText(QCoreApplication::translate("TableSection", "Zn", nullptr));
        btnGallium->setText(QCoreApplication::translate("TableSection", "Ga", nullptr));
        btnGermanium->setText(QCoreApplication::translate("TableSection", "Ge", nullptr));
        btnArsenic->setText(QCoreApplication::translate("TableSection", "As", nullptr));
        btnSelenium->setText(QCoreApplication::translate("TableSection", "Se", nullptr));
        btnBromine->setText(QCoreApplication::translate("TableSection", "Br", nullptr));
        btnKrypton->setText(QCoreApplication::translate("TableSection", "Kr", nullptr));
        btnRubidium->setText(QCoreApplication::translate("TableSection", "Rb", nullptr));
        btnStrontium->setText(QCoreApplication::translate("TableSection", "Sr", nullptr));
        btnYttrium->setText(QCoreApplication::translate("TableSection", "Y", nullptr));
        btnZirconium->setText(QCoreApplication::translate("TableSection", "Zr", nullptr));
        btnNiobium->setText(QCoreApplication::translate("TableSection", "Nb", nullptr));
        btnMolybdenum->setText(QCoreApplication::translate("TableSection", "Mo", nullptr));
        btnTechnetium->setText(QCoreApplication::translate("TableSection", "Tc", nullptr));
        btnRuthenium->setText(QCoreApplication::translate("TableSection", "Ru", nullptr));
        btnRhodium->setText(QCoreApplication::translate("TableSection", "Rh", nullptr));
        btnPalladium->setText(QCoreApplication::translate("TableSection", "Pd", nullptr));
        btnSilver->setText(QCoreApplication::translate("TableSection", "Ag", nullptr));
        btnCadmium->setText(QCoreApplication::translate("TableSection", "Cd", nullptr));
        btnIndium->setText(QCoreApplication::translate("TableSection", "In", nullptr));
        btnTin->setText(QCoreApplication::translate("TableSection", "Sn", nullptr));
        btnAntimony->setText(QCoreApplication::translate("TableSection", "Sb", nullptr));
        btnTellurium->setText(QCoreApplication::translate("TableSection", "Te", nullptr));
        btnIodine->setText(QCoreApplication::translate("TableSection", "I", nullptr));
        btnXenon->setText(QCoreApplication::translate("TableSection", "Xe", nullptr));
        btnCesium->setText(QCoreApplication::translate("TableSection", "Cs", nullptr));
        btnBarium->setText(QCoreApplication::translate("TableSection", "Ba", nullptr));
        ctnLANTHANIDES->setText(QCoreApplication::translate("TableSection", "La-Lu", nullptr));
        btnHafnium->setText(QCoreApplication::translate("TableSection", "Hf", nullptr));
        btnTantalum->setText(QCoreApplication::translate("TableSection", "Ta", nullptr));
        btnTungsten->setText(QCoreApplication::translate("TableSection", "W", nullptr));
        btnRhenium->setText(QCoreApplication::translate("TableSection", "Re", nullptr));
        btnOsmium->setText(QCoreApplication::translate("TableSection", "Os", nullptr));
        btnIridium->setText(QCoreApplication::translate("TableSection", "Ir", nullptr));
        btnPlatinum->setText(QCoreApplication::translate("TableSection", "Pt", nullptr));
        btnGold->setText(QCoreApplication::translate("TableSection", "Au", nullptr));
        btnMercury->setText(QCoreApplication::translate("TableSection", "Hg", nullptr));
        btnThallium->setText(QCoreApplication::translate("TableSection", "Tl", nullptr));
        btnLead->setText(QCoreApplication::translate("TableSection", "Pb", nullptr));
        btnBismuth->setText(QCoreApplication::translate("TableSection", "Bi", nullptr));
        btnPolonium->setText(QCoreApplication::translate("TableSection", "Po", nullptr));
        btnAstatine->setText(QCoreApplication::translate("TableSection", "At", nullptr));
        btnRadon->setText(QCoreApplication::translate("TableSection", "Rn", nullptr));
        btnFrancium->setText(QCoreApplication::translate("TableSection", "Fr", nullptr));
        btnRadium->setText(QCoreApplication::translate("TableSection", "Ra", nullptr));
        ctnACTINIDES->setText(QCoreApplication::translate("TableSection", "Ac-Lr", nullptr));
        btnRutherfordium->setText(QCoreApplication::translate("TableSection", "Rf", nullptr));
        btnDubnium->setText(QCoreApplication::translate("TableSection", "Db", nullptr));
        btnSeaborgium->setText(QCoreApplication::translate("TableSection", "Sg", nullptr));
        btnBohrium->setText(QCoreApplication::translate("TableSection", "Bh", nullptr));
        btnHassium->setText(QCoreApplication::translate("TableSection", "Hs", nullptr));
        btnMeitnerium->setText(QCoreApplication::translate("TableSection", "Mt", nullptr));
        btnDarmstadtium->setText(QCoreApplication::translate("TableSection", "Ds", nullptr));
        btnRoentgenium->setText(QCoreApplication::translate("TableSection", "Rg", nullptr));
        btnCopernicium->setText(QCoreApplication::translate("TableSection", "Cn", nullptr));
        btnNihonium->setText(QCoreApplication::translate("TableSection", "Nh", nullptr));
        btnFlerovium->setText(QCoreApplication::translate("TableSection", "Fl", nullptr));
        btnMoscovium->setText(QCoreApplication::translate("TableSection", "Mc", nullptr));
        btnLivermorium->setText(QCoreApplication::translate("TableSection", "Lv", nullptr));
        btnTennessine->setText(QCoreApplication::translate("TableSection", "Ts", nullptr));
        btnOganesson->setText(QCoreApplication::translate("TableSection", "Og", nullptr));
        btnLanthanum->setText(QCoreApplication::translate("TableSection", "La", nullptr));
        btnCerium->setText(QCoreApplication::translate("TableSection", "Ce", nullptr));
        btnPraseodymium->setText(QCoreApplication::translate("TableSection", "Pr", nullptr));
        btnNeodymium->setText(QCoreApplication::translate("TableSection", "Nd", nullptr));
        btnPromethium->setText(QCoreApplication::translate("TableSection", "Pm", nullptr));
        btnSamarium->setText(QCoreApplication::translate("TableSection", "Sm", nullptr));
        btnEuropium->setText(QCoreApplication::translate("TableSection", "Eu", nullptr));
        btnGadolinium->setText(QCoreApplication::translate("TableSection", "Gd", nullptr));
        btnTerbium->setText(QCoreApplication::translate("TableSection", "Tb", nullptr));
        btnDysprosium->setText(QCoreApplication::translate("TableSection", "Dy", nullptr));
        btnHolmium->setText(QCoreApplication::translate("TableSection", "Ho", nullptr));
        btnErbium->setText(QCoreApplication::translate("TableSection", "Er", nullptr));
        btnThulium->setText(QCoreApplication::translate("TableSection", "Tm", nullptr));
        btnYtterbium->setText(QCoreApplication::translate("TableSection", "Yb", nullptr));
        btnLutetium->setText(QCoreApplication::translate("TableSection", "Lu", nullptr));
        btnActinium->setText(QCoreApplication::translate("TableSection", "Ac", nullptr));
        btnThorium->setText(QCoreApplication::translate("TableSection", "Th", nullptr));
        btnProtactinium->setText(QCoreApplication::translate("TableSection", "Pa", nullptr));
        btnUranium->setText(QCoreApplication::translate("TableSection", "U", nullptr));
        btnNeptunium->setText(QCoreApplication::translate("TableSection", "Np", nullptr));
        btnPlutonium->setText(QCoreApplication::translate("TableSection", "Pu", nullptr));
        btnAmericium->setText(QCoreApplication::translate("TableSection", "Am", nullptr));
        btnCurium->setText(QCoreApplication::translate("TableSection", "Cm", nullptr));
        btnBerkelium->setText(QCoreApplication::translate("TableSection", "Bk", nullptr));
        btnCalifornium->setText(QCoreApplication::translate("TableSection", "Cf", nullptr));
        btnEinsteinium->setText(QCoreApplication::translate("TableSection", "Es", nullptr));
        btnFermium->setText(QCoreApplication::translate("TableSection", "Fm", nullptr));
        btnMendelevium->setText(QCoreApplication::translate("TableSection", "Md", nullptr));
        btnNobelium->setText(QCoreApplication::translate("TableSection", "No", nullptr));
        btnLawrencium->setText(QCoreApplication::translate("TableSection", "Lr", nullptr));
    } // retranslateUi

};

namespace Ui {
    class TableSection: public Ui_TableSection {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TABLESECTION_H

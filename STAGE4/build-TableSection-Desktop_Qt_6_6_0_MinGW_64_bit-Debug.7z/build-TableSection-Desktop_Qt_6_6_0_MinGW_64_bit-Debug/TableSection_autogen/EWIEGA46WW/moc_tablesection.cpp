/****************************************************************************
** Meta object code from reading C++ file 'tablesection.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.6.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../TableSection/tablesection.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'tablesection.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.6.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSTableSectionENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSTableSectionENDCLASS = QtMocHelpers::stringData(
    "TableSection",
    "on_rbtnCategories_clicked",
    "",
    "on_rbtnMetallic_Properties_clicked",
    "on_rbtnBlocks_clicked",
    "on_rbtnPhases_clicked",
    "onElementPropertySelected",
    "index",
    "on_btnHydrogen_clicked",
    "on_btnHelium_clicked",
    "on_btnLithium_clicked",
    "on_btnBeryllium_clicked",
    "on_btnBoron_clicked",
    "on_btnCarbon_clicked",
    "on_btnNitrogen_clicked",
    "on_btnOxygen_clicked",
    "on_btnFluorine_clicked",
    "on_btnNeon_clicked",
    "on_btnSodium_clicked",
    "on_btnMagnesium_clicked",
    "on_btnAluminum_clicked",
    "on_btnSilicon_clicked",
    "on_btnPhosphorus_clicked",
    "on_btnSulfur_clicked",
    "on_btnChlorine_clicked",
    "on_btnArgon_clicked",
    "on_btnPotassium_clicked",
    "on_btnCalcium_clicked",
    "on_btnScandium_clicked",
    "on_btnTitanium_clicked",
    "on_btnVanadium_clicked",
    "on_btnChromium_clicked",
    "on_btnManganese_clicked",
    "on_btnIron_clicked",
    "on_btnCobalt_clicked",
    "on_btnNickel_clicked",
    "on_btnCopper_clicked",
    "on_btnZinc_clicked",
    "on_btnGallium_clicked",
    "on_btnGermanium_clicked",
    "on_btnArsenic_clicked",
    "on_btnSelenium_clicked",
    "on_btnBromine_clicked",
    "on_btnKrypton_clicked",
    "on_btnRubidium_clicked",
    "on_btnStrontium_clicked",
    "on_btnYttrium_clicked",
    "on_btnZirconium_clicked",
    "on_btnNiobium_clicked",
    "on_btnMolybdenum_clicked",
    "on_btnTechnetium_clicked",
    "on_btnRuthenium_clicked",
    "on_btnRhodium_clicked",
    "on_btnPalladium_clicked",
    "on_btnSilver_clicked",
    "on_btnCadmium_clicked",
    "on_btnIndium_clicked",
    "on_btnTin_clicked",
    "on_btnAntimony_clicked",
    "on_btnTellurium_clicked",
    "on_btnIodine_clicked",
    "on_btnXenon_clicked",
    "on_btnCesium_clicked",
    "on_btnBarium_clicked",
    "on_btnLanthanum_clicked",
    "on_btnCerium_clicked",
    "on_btnPraseodymium_clicked",
    "on_btnNeodymium_clicked",
    "on_btnPromethium_clicked",
    "on_btnSamarium_clicked",
    "on_btnEuropium_clicked",
    "on_btnGadolinium_clicked",
    "on_btnTerbium_clicked",
    "on_btnDysprosium_clicked",
    "on_btnHolmium_clicked",
    "on_btnErbium_clicked",
    "on_btnThulium_clicked",
    "on_btnYtterbium_clicked",
    "on_btnLutetium_clicked",
    "on_btnHafnium_clicked",
    "on_btnTantalum_clicked",
    "on_btnTungsten_clicked",
    "on_btnRhenium_clicked",
    "on_btnOsmium_clicked",
    "on_btnIridium_clicked",
    "on_btnPlatinum_clicked",
    "on_btnGold_clicked",
    "on_btnMercury_clicked",
    "on_btnThallium_clicked",
    "on_btnLead_clicked",
    "on_btnBismuth_clicked",
    "on_btnPolonium_clicked",
    "on_btnAstatine_clicked",
    "on_btnRadon_clicked",
    "on_btnFrancium_clicked",
    "on_btnRadium_clicked",
    "on_btnActinium_clicked",
    "on_btnThorium_clicked",
    "on_btnProtactinium_clicked",
    "on_btnUranium_clicked",
    "on_btnNeptunium_clicked",
    "on_btnPlutonium_clicked",
    "on_btnAmericium_clicked",
    "on_btnCurium_clicked",
    "on_btnBerkelium_clicked",
    "on_btnCalifornium_clicked",
    "on_btnEinsteinium_clicked",
    "on_btnFermium_clicked",
    "on_btnMendelevium_clicked",
    "on_btnNobelium_clicked",
    "on_btnLawrencium_clicked",
    "on_btnRutherfordium_clicked",
    "on_btnDubnium_clicked",
    "on_btnSeaborgium_clicked",
    "on_btnBohrium_clicked",
    "on_btnHassium_clicked",
    "on_btnMeitnerium_clicked",
    "on_btnDarmstadtium_clicked",
    "on_btnRoentgenium_clicked",
    "on_btnCopernicium_clicked",
    "on_btnNihonium_clicked",
    "on_btnFlerovium_clicked",
    "on_btnMoscovium_clicked",
    "on_btnLivermorium_clicked",
    "on_btnTennessine_clicked",
    "on_btnOganesson_clicked"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSTableSectionENDCLASS_t {
    uint offsetsAndSizes[252];
    char stringdata0[13];
    char stringdata1[26];
    char stringdata2[1];
    char stringdata3[35];
    char stringdata4[22];
    char stringdata5[22];
    char stringdata6[26];
    char stringdata7[6];
    char stringdata8[23];
    char stringdata9[21];
    char stringdata10[22];
    char stringdata11[24];
    char stringdata12[20];
    char stringdata13[21];
    char stringdata14[23];
    char stringdata15[21];
    char stringdata16[23];
    char stringdata17[19];
    char stringdata18[21];
    char stringdata19[24];
    char stringdata20[23];
    char stringdata21[22];
    char stringdata22[25];
    char stringdata23[21];
    char stringdata24[23];
    char stringdata25[20];
    char stringdata26[24];
    char stringdata27[22];
    char stringdata28[23];
    char stringdata29[23];
    char stringdata30[23];
    char stringdata31[23];
    char stringdata32[24];
    char stringdata33[19];
    char stringdata34[21];
    char stringdata35[21];
    char stringdata36[21];
    char stringdata37[19];
    char stringdata38[22];
    char stringdata39[24];
    char stringdata40[22];
    char stringdata41[23];
    char stringdata42[22];
    char stringdata43[22];
    char stringdata44[23];
    char stringdata45[24];
    char stringdata46[22];
    char stringdata47[24];
    char stringdata48[22];
    char stringdata49[25];
    char stringdata50[25];
    char stringdata51[24];
    char stringdata52[22];
    char stringdata53[24];
    char stringdata54[21];
    char stringdata55[22];
    char stringdata56[21];
    char stringdata57[18];
    char stringdata58[23];
    char stringdata59[24];
    char stringdata60[21];
    char stringdata61[20];
    char stringdata62[21];
    char stringdata63[21];
    char stringdata64[24];
    char stringdata65[21];
    char stringdata66[27];
    char stringdata67[24];
    char stringdata68[25];
    char stringdata69[23];
    char stringdata70[23];
    char stringdata71[25];
    char stringdata72[22];
    char stringdata73[25];
    char stringdata74[22];
    char stringdata75[21];
    char stringdata76[22];
    char stringdata77[24];
    char stringdata78[23];
    char stringdata79[22];
    char stringdata80[23];
    char stringdata81[23];
    char stringdata82[22];
    char stringdata83[21];
    char stringdata84[22];
    char stringdata85[23];
    char stringdata86[19];
    char stringdata87[22];
    char stringdata88[23];
    char stringdata89[19];
    char stringdata90[22];
    char stringdata91[23];
    char stringdata92[23];
    char stringdata93[20];
    char stringdata94[23];
    char stringdata95[21];
    char stringdata96[23];
    char stringdata97[22];
    char stringdata98[27];
    char stringdata99[22];
    char stringdata100[24];
    char stringdata101[24];
    char stringdata102[24];
    char stringdata103[21];
    char stringdata104[24];
    char stringdata105[26];
    char stringdata106[26];
    char stringdata107[22];
    char stringdata108[26];
    char stringdata109[23];
    char stringdata110[25];
    char stringdata111[28];
    char stringdata112[22];
    char stringdata113[25];
    char stringdata114[22];
    char stringdata115[22];
    char stringdata116[25];
    char stringdata117[27];
    char stringdata118[26];
    char stringdata119[26];
    char stringdata120[23];
    char stringdata121[24];
    char stringdata122[24];
    char stringdata123[26];
    char stringdata124[25];
    char stringdata125[24];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSTableSectionENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSTableSectionENDCLASS_t qt_meta_stringdata_CLASSTableSectionENDCLASS = {
    {
        QT_MOC_LITERAL(0, 12),  // "TableSection"
        QT_MOC_LITERAL(13, 25),  // "on_rbtnCategories_clicked"
        QT_MOC_LITERAL(39, 0),  // ""
        QT_MOC_LITERAL(40, 34),  // "on_rbtnMetallic_Properties_cl..."
        QT_MOC_LITERAL(75, 21),  // "on_rbtnBlocks_clicked"
        QT_MOC_LITERAL(97, 21),  // "on_rbtnPhases_clicked"
        QT_MOC_LITERAL(119, 25),  // "onElementPropertySelected"
        QT_MOC_LITERAL(145, 5),  // "index"
        QT_MOC_LITERAL(151, 22),  // "on_btnHydrogen_clicked"
        QT_MOC_LITERAL(174, 20),  // "on_btnHelium_clicked"
        QT_MOC_LITERAL(195, 21),  // "on_btnLithium_clicked"
        QT_MOC_LITERAL(217, 23),  // "on_btnBeryllium_clicked"
        QT_MOC_LITERAL(241, 19),  // "on_btnBoron_clicked"
        QT_MOC_LITERAL(261, 20),  // "on_btnCarbon_clicked"
        QT_MOC_LITERAL(282, 22),  // "on_btnNitrogen_clicked"
        QT_MOC_LITERAL(305, 20),  // "on_btnOxygen_clicked"
        QT_MOC_LITERAL(326, 22),  // "on_btnFluorine_clicked"
        QT_MOC_LITERAL(349, 18),  // "on_btnNeon_clicked"
        QT_MOC_LITERAL(368, 20),  // "on_btnSodium_clicked"
        QT_MOC_LITERAL(389, 23),  // "on_btnMagnesium_clicked"
        QT_MOC_LITERAL(413, 22),  // "on_btnAluminum_clicked"
        QT_MOC_LITERAL(436, 21),  // "on_btnSilicon_clicked"
        QT_MOC_LITERAL(458, 24),  // "on_btnPhosphorus_clicked"
        QT_MOC_LITERAL(483, 20),  // "on_btnSulfur_clicked"
        QT_MOC_LITERAL(504, 22),  // "on_btnChlorine_clicked"
        QT_MOC_LITERAL(527, 19),  // "on_btnArgon_clicked"
        QT_MOC_LITERAL(547, 23),  // "on_btnPotassium_clicked"
        QT_MOC_LITERAL(571, 21),  // "on_btnCalcium_clicked"
        QT_MOC_LITERAL(593, 22),  // "on_btnScandium_clicked"
        QT_MOC_LITERAL(616, 22),  // "on_btnTitanium_clicked"
        QT_MOC_LITERAL(639, 22),  // "on_btnVanadium_clicked"
        QT_MOC_LITERAL(662, 22),  // "on_btnChromium_clicked"
        QT_MOC_LITERAL(685, 23),  // "on_btnManganese_clicked"
        QT_MOC_LITERAL(709, 18),  // "on_btnIron_clicked"
        QT_MOC_LITERAL(728, 20),  // "on_btnCobalt_clicked"
        QT_MOC_LITERAL(749, 20),  // "on_btnNickel_clicked"
        QT_MOC_LITERAL(770, 20),  // "on_btnCopper_clicked"
        QT_MOC_LITERAL(791, 18),  // "on_btnZinc_clicked"
        QT_MOC_LITERAL(810, 21),  // "on_btnGallium_clicked"
        QT_MOC_LITERAL(832, 23),  // "on_btnGermanium_clicked"
        QT_MOC_LITERAL(856, 21),  // "on_btnArsenic_clicked"
        QT_MOC_LITERAL(878, 22),  // "on_btnSelenium_clicked"
        QT_MOC_LITERAL(901, 21),  // "on_btnBromine_clicked"
        QT_MOC_LITERAL(923, 21),  // "on_btnKrypton_clicked"
        QT_MOC_LITERAL(945, 22),  // "on_btnRubidium_clicked"
        QT_MOC_LITERAL(968, 23),  // "on_btnStrontium_clicked"
        QT_MOC_LITERAL(992, 21),  // "on_btnYttrium_clicked"
        QT_MOC_LITERAL(1014, 23),  // "on_btnZirconium_clicked"
        QT_MOC_LITERAL(1038, 21),  // "on_btnNiobium_clicked"
        QT_MOC_LITERAL(1060, 24),  // "on_btnMolybdenum_clicked"
        QT_MOC_LITERAL(1085, 24),  // "on_btnTechnetium_clicked"
        QT_MOC_LITERAL(1110, 23),  // "on_btnRuthenium_clicked"
        QT_MOC_LITERAL(1134, 21),  // "on_btnRhodium_clicked"
        QT_MOC_LITERAL(1156, 23),  // "on_btnPalladium_clicked"
        QT_MOC_LITERAL(1180, 20),  // "on_btnSilver_clicked"
        QT_MOC_LITERAL(1201, 21),  // "on_btnCadmium_clicked"
        QT_MOC_LITERAL(1223, 20),  // "on_btnIndium_clicked"
        QT_MOC_LITERAL(1244, 17),  // "on_btnTin_clicked"
        QT_MOC_LITERAL(1262, 22),  // "on_btnAntimony_clicked"
        QT_MOC_LITERAL(1285, 23),  // "on_btnTellurium_clicked"
        QT_MOC_LITERAL(1309, 20),  // "on_btnIodine_clicked"
        QT_MOC_LITERAL(1330, 19),  // "on_btnXenon_clicked"
        QT_MOC_LITERAL(1350, 20),  // "on_btnCesium_clicked"
        QT_MOC_LITERAL(1371, 20),  // "on_btnBarium_clicked"
        QT_MOC_LITERAL(1392, 23),  // "on_btnLanthanum_clicked"
        QT_MOC_LITERAL(1416, 20),  // "on_btnCerium_clicked"
        QT_MOC_LITERAL(1437, 26),  // "on_btnPraseodymium_clicked"
        QT_MOC_LITERAL(1464, 23),  // "on_btnNeodymium_clicked"
        QT_MOC_LITERAL(1488, 24),  // "on_btnPromethium_clicked"
        QT_MOC_LITERAL(1513, 22),  // "on_btnSamarium_clicked"
        QT_MOC_LITERAL(1536, 22),  // "on_btnEuropium_clicked"
        QT_MOC_LITERAL(1559, 24),  // "on_btnGadolinium_clicked"
        QT_MOC_LITERAL(1584, 21),  // "on_btnTerbium_clicked"
        QT_MOC_LITERAL(1606, 24),  // "on_btnDysprosium_clicked"
        QT_MOC_LITERAL(1631, 21),  // "on_btnHolmium_clicked"
        QT_MOC_LITERAL(1653, 20),  // "on_btnErbium_clicked"
        QT_MOC_LITERAL(1674, 21),  // "on_btnThulium_clicked"
        QT_MOC_LITERAL(1696, 23),  // "on_btnYtterbium_clicked"
        QT_MOC_LITERAL(1720, 22),  // "on_btnLutetium_clicked"
        QT_MOC_LITERAL(1743, 21),  // "on_btnHafnium_clicked"
        QT_MOC_LITERAL(1765, 22),  // "on_btnTantalum_clicked"
        QT_MOC_LITERAL(1788, 22),  // "on_btnTungsten_clicked"
        QT_MOC_LITERAL(1811, 21),  // "on_btnRhenium_clicked"
        QT_MOC_LITERAL(1833, 20),  // "on_btnOsmium_clicked"
        QT_MOC_LITERAL(1854, 21),  // "on_btnIridium_clicked"
        QT_MOC_LITERAL(1876, 22),  // "on_btnPlatinum_clicked"
        QT_MOC_LITERAL(1899, 18),  // "on_btnGold_clicked"
        QT_MOC_LITERAL(1918, 21),  // "on_btnMercury_clicked"
        QT_MOC_LITERAL(1940, 22),  // "on_btnThallium_clicked"
        QT_MOC_LITERAL(1963, 18),  // "on_btnLead_clicked"
        QT_MOC_LITERAL(1982, 21),  // "on_btnBismuth_clicked"
        QT_MOC_LITERAL(2004, 22),  // "on_btnPolonium_clicked"
        QT_MOC_LITERAL(2027, 22),  // "on_btnAstatine_clicked"
        QT_MOC_LITERAL(2050, 19),  // "on_btnRadon_clicked"
        QT_MOC_LITERAL(2070, 22),  // "on_btnFrancium_clicked"
        QT_MOC_LITERAL(2093, 20),  // "on_btnRadium_clicked"
        QT_MOC_LITERAL(2114, 22),  // "on_btnActinium_clicked"
        QT_MOC_LITERAL(2137, 21),  // "on_btnThorium_clicked"
        QT_MOC_LITERAL(2159, 26),  // "on_btnProtactinium_clicked"
        QT_MOC_LITERAL(2186, 21),  // "on_btnUranium_clicked"
        QT_MOC_LITERAL(2208, 23),  // "on_btnNeptunium_clicked"
        QT_MOC_LITERAL(2232, 23),  // "on_btnPlutonium_clicked"
        QT_MOC_LITERAL(2256, 23),  // "on_btnAmericium_clicked"
        QT_MOC_LITERAL(2280, 20),  // "on_btnCurium_clicked"
        QT_MOC_LITERAL(2301, 23),  // "on_btnBerkelium_clicked"
        QT_MOC_LITERAL(2325, 25),  // "on_btnCalifornium_clicked"
        QT_MOC_LITERAL(2351, 25),  // "on_btnEinsteinium_clicked"
        QT_MOC_LITERAL(2377, 21),  // "on_btnFermium_clicked"
        QT_MOC_LITERAL(2399, 25),  // "on_btnMendelevium_clicked"
        QT_MOC_LITERAL(2425, 22),  // "on_btnNobelium_clicked"
        QT_MOC_LITERAL(2448, 24),  // "on_btnLawrencium_clicked"
        QT_MOC_LITERAL(2473, 27),  // "on_btnRutherfordium_clicked"
        QT_MOC_LITERAL(2501, 21),  // "on_btnDubnium_clicked"
        QT_MOC_LITERAL(2523, 24),  // "on_btnSeaborgium_clicked"
        QT_MOC_LITERAL(2548, 21),  // "on_btnBohrium_clicked"
        QT_MOC_LITERAL(2570, 21),  // "on_btnHassium_clicked"
        QT_MOC_LITERAL(2592, 24),  // "on_btnMeitnerium_clicked"
        QT_MOC_LITERAL(2617, 26),  // "on_btnDarmstadtium_clicked"
        QT_MOC_LITERAL(2644, 25),  // "on_btnRoentgenium_clicked"
        QT_MOC_LITERAL(2670, 25),  // "on_btnCopernicium_clicked"
        QT_MOC_LITERAL(2696, 22),  // "on_btnNihonium_clicked"
        QT_MOC_LITERAL(2719, 23),  // "on_btnFlerovium_clicked"
        QT_MOC_LITERAL(2743, 23),  // "on_btnMoscovium_clicked"
        QT_MOC_LITERAL(2767, 25),  // "on_btnLivermorium_clicked"
        QT_MOC_LITERAL(2793, 24),  // "on_btnTennessine_clicked"
        QT_MOC_LITERAL(2818, 23)   // "on_btnOganesson_clicked"
    },
    "TableSection",
    "on_rbtnCategories_clicked",
    "",
    "on_rbtnMetallic_Properties_clicked",
    "on_rbtnBlocks_clicked",
    "on_rbtnPhases_clicked",
    "onElementPropertySelected",
    "index",
    "on_btnHydrogen_clicked",
    "on_btnHelium_clicked",
    "on_btnLithium_clicked",
    "on_btnBeryllium_clicked",
    "on_btnBoron_clicked",
    "on_btnCarbon_clicked",
    "on_btnNitrogen_clicked",
    "on_btnOxygen_clicked",
    "on_btnFluorine_clicked",
    "on_btnNeon_clicked",
    "on_btnSodium_clicked",
    "on_btnMagnesium_clicked",
    "on_btnAluminum_clicked",
    "on_btnSilicon_clicked",
    "on_btnPhosphorus_clicked",
    "on_btnSulfur_clicked",
    "on_btnChlorine_clicked",
    "on_btnArgon_clicked",
    "on_btnPotassium_clicked",
    "on_btnCalcium_clicked",
    "on_btnScandium_clicked",
    "on_btnTitanium_clicked",
    "on_btnVanadium_clicked",
    "on_btnChromium_clicked",
    "on_btnManganese_clicked",
    "on_btnIron_clicked",
    "on_btnCobalt_clicked",
    "on_btnNickel_clicked",
    "on_btnCopper_clicked",
    "on_btnZinc_clicked",
    "on_btnGallium_clicked",
    "on_btnGermanium_clicked",
    "on_btnArsenic_clicked",
    "on_btnSelenium_clicked",
    "on_btnBromine_clicked",
    "on_btnKrypton_clicked",
    "on_btnRubidium_clicked",
    "on_btnStrontium_clicked",
    "on_btnYttrium_clicked",
    "on_btnZirconium_clicked",
    "on_btnNiobium_clicked",
    "on_btnMolybdenum_clicked",
    "on_btnTechnetium_clicked",
    "on_btnRuthenium_clicked",
    "on_btnRhodium_clicked",
    "on_btnPalladium_clicked",
    "on_btnSilver_clicked",
    "on_btnCadmium_clicked",
    "on_btnIndium_clicked",
    "on_btnTin_clicked",
    "on_btnAntimony_clicked",
    "on_btnTellurium_clicked",
    "on_btnIodine_clicked",
    "on_btnXenon_clicked",
    "on_btnCesium_clicked",
    "on_btnBarium_clicked",
    "on_btnLanthanum_clicked",
    "on_btnCerium_clicked",
    "on_btnPraseodymium_clicked",
    "on_btnNeodymium_clicked",
    "on_btnPromethium_clicked",
    "on_btnSamarium_clicked",
    "on_btnEuropium_clicked",
    "on_btnGadolinium_clicked",
    "on_btnTerbium_clicked",
    "on_btnDysprosium_clicked",
    "on_btnHolmium_clicked",
    "on_btnErbium_clicked",
    "on_btnThulium_clicked",
    "on_btnYtterbium_clicked",
    "on_btnLutetium_clicked",
    "on_btnHafnium_clicked",
    "on_btnTantalum_clicked",
    "on_btnTungsten_clicked",
    "on_btnRhenium_clicked",
    "on_btnOsmium_clicked",
    "on_btnIridium_clicked",
    "on_btnPlatinum_clicked",
    "on_btnGold_clicked",
    "on_btnMercury_clicked",
    "on_btnThallium_clicked",
    "on_btnLead_clicked",
    "on_btnBismuth_clicked",
    "on_btnPolonium_clicked",
    "on_btnAstatine_clicked",
    "on_btnRadon_clicked",
    "on_btnFrancium_clicked",
    "on_btnRadium_clicked",
    "on_btnActinium_clicked",
    "on_btnThorium_clicked",
    "on_btnProtactinium_clicked",
    "on_btnUranium_clicked",
    "on_btnNeptunium_clicked",
    "on_btnPlutonium_clicked",
    "on_btnAmericium_clicked",
    "on_btnCurium_clicked",
    "on_btnBerkelium_clicked",
    "on_btnCalifornium_clicked",
    "on_btnEinsteinium_clicked",
    "on_btnFermium_clicked",
    "on_btnMendelevium_clicked",
    "on_btnNobelium_clicked",
    "on_btnLawrencium_clicked",
    "on_btnRutherfordium_clicked",
    "on_btnDubnium_clicked",
    "on_btnSeaborgium_clicked",
    "on_btnBohrium_clicked",
    "on_btnHassium_clicked",
    "on_btnMeitnerium_clicked",
    "on_btnDarmstadtium_clicked",
    "on_btnRoentgenium_clicked",
    "on_btnCopernicium_clicked",
    "on_btnNihonium_clicked",
    "on_btnFlerovium_clicked",
    "on_btnMoscovium_clicked",
    "on_btnLivermorium_clicked",
    "on_btnTennessine_clicked",
    "on_btnOganesson_clicked"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSTableSectionENDCLASS[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
     123,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  752,    2, 0x08,    1 /* Private */,
       3,    0,  753,    2, 0x08,    2 /* Private */,
       4,    0,  754,    2, 0x08,    3 /* Private */,
       5,    0,  755,    2, 0x08,    4 /* Private */,
       6,    1,  756,    2, 0x08,    5 /* Private */,
       8,    0,  759,    2, 0x08,    7 /* Private */,
       9,    0,  760,    2, 0x08,    8 /* Private */,
      10,    0,  761,    2, 0x08,    9 /* Private */,
      11,    0,  762,    2, 0x08,   10 /* Private */,
      12,    0,  763,    2, 0x08,   11 /* Private */,
      13,    0,  764,    2, 0x08,   12 /* Private */,
      14,    0,  765,    2, 0x08,   13 /* Private */,
      15,    0,  766,    2, 0x08,   14 /* Private */,
      16,    0,  767,    2, 0x08,   15 /* Private */,
      17,    0,  768,    2, 0x08,   16 /* Private */,
      18,    0,  769,    2, 0x08,   17 /* Private */,
      19,    0,  770,    2, 0x08,   18 /* Private */,
      20,    0,  771,    2, 0x08,   19 /* Private */,
      21,    0,  772,    2, 0x08,   20 /* Private */,
      22,    0,  773,    2, 0x08,   21 /* Private */,
      23,    0,  774,    2, 0x08,   22 /* Private */,
      24,    0,  775,    2, 0x08,   23 /* Private */,
      25,    0,  776,    2, 0x08,   24 /* Private */,
      26,    0,  777,    2, 0x08,   25 /* Private */,
      27,    0,  778,    2, 0x08,   26 /* Private */,
      28,    0,  779,    2, 0x08,   27 /* Private */,
      29,    0,  780,    2, 0x08,   28 /* Private */,
      30,    0,  781,    2, 0x08,   29 /* Private */,
      31,    0,  782,    2, 0x08,   30 /* Private */,
      32,    0,  783,    2, 0x08,   31 /* Private */,
      33,    0,  784,    2, 0x08,   32 /* Private */,
      34,    0,  785,    2, 0x08,   33 /* Private */,
      35,    0,  786,    2, 0x08,   34 /* Private */,
      36,    0,  787,    2, 0x08,   35 /* Private */,
      37,    0,  788,    2, 0x08,   36 /* Private */,
      38,    0,  789,    2, 0x08,   37 /* Private */,
      39,    0,  790,    2, 0x08,   38 /* Private */,
      40,    0,  791,    2, 0x08,   39 /* Private */,
      41,    0,  792,    2, 0x08,   40 /* Private */,
      42,    0,  793,    2, 0x08,   41 /* Private */,
      43,    0,  794,    2, 0x08,   42 /* Private */,
      44,    0,  795,    2, 0x08,   43 /* Private */,
      45,    0,  796,    2, 0x08,   44 /* Private */,
      46,    0,  797,    2, 0x08,   45 /* Private */,
      47,    0,  798,    2, 0x08,   46 /* Private */,
      48,    0,  799,    2, 0x08,   47 /* Private */,
      49,    0,  800,    2, 0x08,   48 /* Private */,
      50,    0,  801,    2, 0x08,   49 /* Private */,
      51,    0,  802,    2, 0x08,   50 /* Private */,
      52,    0,  803,    2, 0x08,   51 /* Private */,
      53,    0,  804,    2, 0x08,   52 /* Private */,
      54,    0,  805,    2, 0x08,   53 /* Private */,
      55,    0,  806,    2, 0x08,   54 /* Private */,
      56,    0,  807,    2, 0x08,   55 /* Private */,
      57,    0,  808,    2, 0x08,   56 /* Private */,
      58,    0,  809,    2, 0x08,   57 /* Private */,
      59,    0,  810,    2, 0x08,   58 /* Private */,
      60,    0,  811,    2, 0x08,   59 /* Private */,
      61,    0,  812,    2, 0x08,   60 /* Private */,
      62,    0,  813,    2, 0x08,   61 /* Private */,
      63,    0,  814,    2, 0x08,   62 /* Private */,
      64,    0,  815,    2, 0x08,   63 /* Private */,
      65,    0,  816,    2, 0x08,   64 /* Private */,
      66,    0,  817,    2, 0x08,   65 /* Private */,
      67,    0,  818,    2, 0x08,   66 /* Private */,
      68,    0,  819,    2, 0x08,   67 /* Private */,
      69,    0,  820,    2, 0x08,   68 /* Private */,
      70,    0,  821,    2, 0x08,   69 /* Private */,
      71,    0,  822,    2, 0x08,   70 /* Private */,
      72,    0,  823,    2, 0x08,   71 /* Private */,
      73,    0,  824,    2, 0x08,   72 /* Private */,
      74,    0,  825,    2, 0x08,   73 /* Private */,
      75,    0,  826,    2, 0x08,   74 /* Private */,
      76,    0,  827,    2, 0x08,   75 /* Private */,
      77,    0,  828,    2, 0x08,   76 /* Private */,
      78,    0,  829,    2, 0x08,   77 /* Private */,
      79,    0,  830,    2, 0x08,   78 /* Private */,
      80,    0,  831,    2, 0x08,   79 /* Private */,
      81,    0,  832,    2, 0x08,   80 /* Private */,
      82,    0,  833,    2, 0x08,   81 /* Private */,
      83,    0,  834,    2, 0x08,   82 /* Private */,
      84,    0,  835,    2, 0x08,   83 /* Private */,
      85,    0,  836,    2, 0x08,   84 /* Private */,
      86,    0,  837,    2, 0x08,   85 /* Private */,
      87,    0,  838,    2, 0x08,   86 /* Private */,
      88,    0,  839,    2, 0x08,   87 /* Private */,
      89,    0,  840,    2, 0x08,   88 /* Private */,
      90,    0,  841,    2, 0x08,   89 /* Private */,
      91,    0,  842,    2, 0x08,   90 /* Private */,
      92,    0,  843,    2, 0x08,   91 /* Private */,
      93,    0,  844,    2, 0x08,   92 /* Private */,
      94,    0,  845,    2, 0x08,   93 /* Private */,
      95,    0,  846,    2, 0x08,   94 /* Private */,
      96,    0,  847,    2, 0x08,   95 /* Private */,
      97,    0,  848,    2, 0x08,   96 /* Private */,
      98,    0,  849,    2, 0x08,   97 /* Private */,
      99,    0,  850,    2, 0x08,   98 /* Private */,
     100,    0,  851,    2, 0x08,   99 /* Private */,
     101,    0,  852,    2, 0x08,  100 /* Private */,
     102,    0,  853,    2, 0x08,  101 /* Private */,
     103,    0,  854,    2, 0x08,  102 /* Private */,
     104,    0,  855,    2, 0x08,  103 /* Private */,
     105,    0,  856,    2, 0x08,  104 /* Private */,
     106,    0,  857,    2, 0x08,  105 /* Private */,
     107,    0,  858,    2, 0x08,  106 /* Private */,
     108,    0,  859,    2, 0x08,  107 /* Private */,
     109,    0,  860,    2, 0x08,  108 /* Private */,
     110,    0,  861,    2, 0x08,  109 /* Private */,
     111,    0,  862,    2, 0x08,  110 /* Private */,
     112,    0,  863,    2, 0x08,  111 /* Private */,
     113,    0,  864,    2, 0x08,  112 /* Private */,
     114,    0,  865,    2, 0x08,  113 /* Private */,
     115,    0,  866,    2, 0x08,  114 /* Private */,
     116,    0,  867,    2, 0x08,  115 /* Private */,
     117,    0,  868,    2, 0x08,  116 /* Private */,
     118,    0,  869,    2, 0x08,  117 /* Private */,
     119,    0,  870,    2, 0x08,  118 /* Private */,
     120,    0,  871,    2, 0x08,  119 /* Private */,
     121,    0,  872,    2, 0x08,  120 /* Private */,
     122,    0,  873,    2, 0x08,  121 /* Private */,
     123,    0,  874,    2, 0x08,  122 /* Private */,
     124,    0,  875,    2, 0x08,  123 /* Private */,
     125,    0,  876,    2, 0x08,  124 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    7,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject TableSection::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_CLASSTableSectionENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSTableSectionENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSTableSectionENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<TableSection, std::true_type>,
        // method 'on_rbtnCategories_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_rbtnMetallic_Properties_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_rbtnBlocks_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_rbtnPhases_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onElementPropertySelected'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_btnHydrogen_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnHelium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnLithium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnBeryllium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnBoron_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnCarbon_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnNitrogen_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnOxygen_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnFluorine_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnNeon_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnSodium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnMagnesium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnAluminum_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnSilicon_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnPhosphorus_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnSulfur_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnChlorine_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnArgon_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnPotassium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnCalcium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnScandium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnTitanium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnVanadium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnChromium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnManganese_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnIron_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnCobalt_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnNickel_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnCopper_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnZinc_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnGallium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnGermanium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnArsenic_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnSelenium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnBromine_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnKrypton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnRubidium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnStrontium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnYttrium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnZirconium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnNiobium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnMolybdenum_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnTechnetium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnRuthenium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnRhodium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnPalladium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnSilver_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnCadmium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnIndium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnTin_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnAntimony_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnTellurium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnIodine_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnXenon_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnCesium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnBarium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnLanthanum_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnCerium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnPraseodymium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnNeodymium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnPromethium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnSamarium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnEuropium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnGadolinium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnTerbium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnDysprosium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnHolmium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnErbium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnThulium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnYtterbium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnLutetium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnHafnium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnTantalum_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnTungsten_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnRhenium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnOsmium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnIridium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnPlatinum_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnGold_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnMercury_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnThallium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnLead_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnBismuth_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnPolonium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnAstatine_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnRadon_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnFrancium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnRadium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnActinium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnThorium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnProtactinium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnUranium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnNeptunium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnPlutonium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnAmericium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnCurium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnBerkelium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnCalifornium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnEinsteinium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnFermium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnMendelevium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnNobelium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnLawrencium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnRutherfordium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnDubnium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnSeaborgium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnBohrium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnHassium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnMeitnerium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnDarmstadtium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnRoentgenium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnCopernicium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnNihonium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnFlerovium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnMoscovium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnLivermorium_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnTennessine_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnOganesson_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void TableSection::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<TableSection *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->on_rbtnCategories_clicked(); break;
        case 1: _t->on_rbtnMetallic_Properties_clicked(); break;
        case 2: _t->on_rbtnBlocks_clicked(); break;
        case 3: _t->on_rbtnPhases_clicked(); break;
        case 4: _t->onElementPropertySelected((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 5: _t->on_btnHydrogen_clicked(); break;
        case 6: _t->on_btnHelium_clicked(); break;
        case 7: _t->on_btnLithium_clicked(); break;
        case 8: _t->on_btnBeryllium_clicked(); break;
        case 9: _t->on_btnBoron_clicked(); break;
        case 10: _t->on_btnCarbon_clicked(); break;
        case 11: _t->on_btnNitrogen_clicked(); break;
        case 12: _t->on_btnOxygen_clicked(); break;
        case 13: _t->on_btnFluorine_clicked(); break;
        case 14: _t->on_btnNeon_clicked(); break;
        case 15: _t->on_btnSodium_clicked(); break;
        case 16: _t->on_btnMagnesium_clicked(); break;
        case 17: _t->on_btnAluminum_clicked(); break;
        case 18: _t->on_btnSilicon_clicked(); break;
        case 19: _t->on_btnPhosphorus_clicked(); break;
        case 20: _t->on_btnSulfur_clicked(); break;
        case 21: _t->on_btnChlorine_clicked(); break;
        case 22: _t->on_btnArgon_clicked(); break;
        case 23: _t->on_btnPotassium_clicked(); break;
        case 24: _t->on_btnCalcium_clicked(); break;
        case 25: _t->on_btnScandium_clicked(); break;
        case 26: _t->on_btnTitanium_clicked(); break;
        case 27: _t->on_btnVanadium_clicked(); break;
        case 28: _t->on_btnChromium_clicked(); break;
        case 29: _t->on_btnManganese_clicked(); break;
        case 30: _t->on_btnIron_clicked(); break;
        case 31: _t->on_btnCobalt_clicked(); break;
        case 32: _t->on_btnNickel_clicked(); break;
        case 33: _t->on_btnCopper_clicked(); break;
        case 34: _t->on_btnZinc_clicked(); break;
        case 35: _t->on_btnGallium_clicked(); break;
        case 36: _t->on_btnGermanium_clicked(); break;
        case 37: _t->on_btnArsenic_clicked(); break;
        case 38: _t->on_btnSelenium_clicked(); break;
        case 39: _t->on_btnBromine_clicked(); break;
        case 40: _t->on_btnKrypton_clicked(); break;
        case 41: _t->on_btnRubidium_clicked(); break;
        case 42: _t->on_btnStrontium_clicked(); break;
        case 43: _t->on_btnYttrium_clicked(); break;
        case 44: _t->on_btnZirconium_clicked(); break;
        case 45: _t->on_btnNiobium_clicked(); break;
        case 46: _t->on_btnMolybdenum_clicked(); break;
        case 47: _t->on_btnTechnetium_clicked(); break;
        case 48: _t->on_btnRuthenium_clicked(); break;
        case 49: _t->on_btnRhodium_clicked(); break;
        case 50: _t->on_btnPalladium_clicked(); break;
        case 51: _t->on_btnSilver_clicked(); break;
        case 52: _t->on_btnCadmium_clicked(); break;
        case 53: _t->on_btnIndium_clicked(); break;
        case 54: _t->on_btnTin_clicked(); break;
        case 55: _t->on_btnAntimony_clicked(); break;
        case 56: _t->on_btnTellurium_clicked(); break;
        case 57: _t->on_btnIodine_clicked(); break;
        case 58: _t->on_btnXenon_clicked(); break;
        case 59: _t->on_btnCesium_clicked(); break;
        case 60: _t->on_btnBarium_clicked(); break;
        case 61: _t->on_btnLanthanum_clicked(); break;
        case 62: _t->on_btnCerium_clicked(); break;
        case 63: _t->on_btnPraseodymium_clicked(); break;
        case 64: _t->on_btnNeodymium_clicked(); break;
        case 65: _t->on_btnPromethium_clicked(); break;
        case 66: _t->on_btnSamarium_clicked(); break;
        case 67: _t->on_btnEuropium_clicked(); break;
        case 68: _t->on_btnGadolinium_clicked(); break;
        case 69: _t->on_btnTerbium_clicked(); break;
        case 70: _t->on_btnDysprosium_clicked(); break;
        case 71: _t->on_btnHolmium_clicked(); break;
        case 72: _t->on_btnErbium_clicked(); break;
        case 73: _t->on_btnThulium_clicked(); break;
        case 74: _t->on_btnYtterbium_clicked(); break;
        case 75: _t->on_btnLutetium_clicked(); break;
        case 76: _t->on_btnHafnium_clicked(); break;
        case 77: _t->on_btnTantalum_clicked(); break;
        case 78: _t->on_btnTungsten_clicked(); break;
        case 79: _t->on_btnRhenium_clicked(); break;
        case 80: _t->on_btnOsmium_clicked(); break;
        case 81: _t->on_btnIridium_clicked(); break;
        case 82: _t->on_btnPlatinum_clicked(); break;
        case 83: _t->on_btnGold_clicked(); break;
        case 84: _t->on_btnMercury_clicked(); break;
        case 85: _t->on_btnThallium_clicked(); break;
        case 86: _t->on_btnLead_clicked(); break;
        case 87: _t->on_btnBismuth_clicked(); break;
        case 88: _t->on_btnPolonium_clicked(); break;
        case 89: _t->on_btnAstatine_clicked(); break;
        case 90: _t->on_btnRadon_clicked(); break;
        case 91: _t->on_btnFrancium_clicked(); break;
        case 92: _t->on_btnRadium_clicked(); break;
        case 93: _t->on_btnActinium_clicked(); break;
        case 94: _t->on_btnThorium_clicked(); break;
        case 95: _t->on_btnProtactinium_clicked(); break;
        case 96: _t->on_btnUranium_clicked(); break;
        case 97: _t->on_btnNeptunium_clicked(); break;
        case 98: _t->on_btnPlutonium_clicked(); break;
        case 99: _t->on_btnAmericium_clicked(); break;
        case 100: _t->on_btnCurium_clicked(); break;
        case 101: _t->on_btnBerkelium_clicked(); break;
        case 102: _t->on_btnCalifornium_clicked(); break;
        case 103: _t->on_btnEinsteinium_clicked(); break;
        case 104: _t->on_btnFermium_clicked(); break;
        case 105: _t->on_btnMendelevium_clicked(); break;
        case 106: _t->on_btnNobelium_clicked(); break;
        case 107: _t->on_btnLawrencium_clicked(); break;
        case 108: _t->on_btnRutherfordium_clicked(); break;
        case 109: _t->on_btnDubnium_clicked(); break;
        case 110: _t->on_btnSeaborgium_clicked(); break;
        case 111: _t->on_btnBohrium_clicked(); break;
        case 112: _t->on_btnHassium_clicked(); break;
        case 113: _t->on_btnMeitnerium_clicked(); break;
        case 114: _t->on_btnDarmstadtium_clicked(); break;
        case 115: _t->on_btnRoentgenium_clicked(); break;
        case 116: _t->on_btnCopernicium_clicked(); break;
        case 117: _t->on_btnNihonium_clicked(); break;
        case 118: _t->on_btnFlerovium_clicked(); break;
        case 119: _t->on_btnMoscovium_clicked(); break;
        case 120: _t->on_btnLivermorium_clicked(); break;
        case 121: _t->on_btnTennessine_clicked(); break;
        case 122: _t->on_btnOganesson_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject *TableSection::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *TableSection::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSTableSectionENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int TableSection::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 123)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 123;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 123)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 123;
    }
    return _id;
}
QT_WARNING_POP
